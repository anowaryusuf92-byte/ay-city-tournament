package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

const val ADMIN_UID = "EIfrjJZWpeNTvhju1C2oYHVhHY62"

@IgnoreExtraProperties
data class UserProfile(
    @DocumentId val id: String = "",
    val uid: String = "",
    val playerUid: String = "",
    val name: String = "",
    val email: String = "",
    val phoneNumber: String = "",
    val phone: String = "",
    val photoUrl: String = "",
    val dlsTeamName: String = "",
    val ffUid: String = "",
    val ffInGameName: String = "",
    val referralCode: String = "",
    val referredBy: String = "",
    val hasActivatedReferral: Boolean = false,
    val walletBalance: Double = 5.0, // Automatic 5 BDT Welcome Bonus
    val balance: Double = 0.0,
    val totalMatchesPlayed: Int = 0,
    val totalMatchesWon: Int = 0,
    val totalPrizeWon: Double = 0.0,
    val role: String = "user", // "user" or "admin"
    val hasReceivedBonus: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class TournamentMatch(
    val matchId: String = "",
    val gameType: String = "", 
    val matchTitle: String = "",
    val matchTime: String = "",
    val winPrize: String = "",
    val entryFee: String = "",
    val entryType: String = "Solo",
    val slotLimit: String = "1/2",
    val status: String = "UPCOMING", 
    val roomCode: String = "",
    val matchRules: String = ""
)

@IgnoreExtraProperties
data class Tournament(
    @DocumentId val id: String = "",
    val title: String = "",
    val gameCategory: String = "DLS", // "DLS", "Free Fire", "eFootball", "Carrom Pool", "Ludo King"
    val matchType: String = "1v1 Classic",
    val mapType: String = "Bermuda", // Bermuda, Kalahari, Purgatory, Stadium
    val entryFee: Double = 0.0,
    val prizePool: Double = 0.0,
    val runnerUpPrize: Double = 0.0,
    val maxSlots: Int = 2,
    val joinedCount: Int = 0,
    val matchTime: String = "",
    val status: String = "UPCOMING", // "UPCOMING", "LIVE", "COMPLETED", "CANCELLED"
    val roomCode: String = "",
    val roomPassword: String = "",
    val winnerId: String = "",
    val winnerName: String = "",
    val rules: String = "১. সময়মতো গেমে উপস্থিত হতে হবে।\n২. ফেয়ার প্লে বজায় রাখতে হবে।\n৩. ম্যাচ শেষে স্ক্রিনশট গ্রুপ/এডমিনকে দিতে হবে।",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Participant(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val dlsTeamName: String = "",
    val inGameName: String = "",
    val gameUid: String = "",
    val gameCategory: String = "DLS",
    val phoneNumber: String = "",
    val slotNumber: Int = 1,
    @ServerTimestamp val joinedAt: Timestamp? = null
)

object GameCategories {
    const val ALL = "ALL"
    const val DLS = "DLS"
    const val FREE_FIRE = "Free Fire"
    const val EFOOTBALL = "eFootball"
    const val CARROM = "Carrom Pool"
    const val LUDO = "Ludo King"

    val list = listOf(DLS, FREE_FIRE, EFOOTBALL, CARROM, LUDO)

    fun getDefaultRules(category: String): String {
        return when (category) {
            FREE_FIRE -> "🔥 ফ্রি ফায়ার ম্যাচ নিয়মাবলী:\n" +
                    "১. ম্যাচ শুরুর ১০-১৫ মিনিট আগে রুম আইডি ও পাসওয়ার্ড দেওয়া হবে।\n" +
                    "২. কোনো প্রকার হ্যাক, স্ক্রিপ্ট, বা কনফিগ ফাইল ব্যবহার করা সম্পূর্ণ নিষিদ্ধ (ধরা পড়লে আজীবন ব্যান)।\n" +
                    "৩. এমুলেটর/পিসি প্লেয়ার নট এলাউড (শুধুমাত্র মোবাইল প্লেয়ার)।\n" +
                    "৪. ম্যাচ শেষে বিজয়ী প্লেয়ার/টিমকে স্কোরের ক্লিয়ার স্ক্রিনশট দিতে হবে।"
            DLS -> "⚽ DLS ফুটবল ম্যাচ নিয়মাবলী:\n" +
                    "১. নির্ধারিত সময়ে সঠিক রুম কোডে গেমে কানেক্ট হতে হবে।\n" +
                    "২. ইচ্ছাকৃত ইন্টারনেট ডিসকানেক্ট বা গেম কুয়িট করলে প্রতিপক্ষ বিজয়ী হবে।\n" +
                    "৩. ফুল-টাইম স্কোরের স্ক্রিনশট গ্রুপে বা অ্যাডমিনকে জমা দিতে হবে।"
            EFOOTBALL -> "🎮 eFootball ম্যাচ নিয়মাবলী:\n" +
                    "১. ফ্রেন্ডলি ম্যাচ রুমে ১০ মিনিটের ম্যাচ অনুষ্ঠিত হবে।\n" +
                    "২. নেটওয়ার্ক স্ট্যাবল রেখে ফেয়ার প্লে নিশ্চিত করুন।\n" +
                    "৩. ম্যাচ রেজাল্ট স্ক্রিনশট আবশ্যক।"
            CARROM -> "⚪ ক্যারম পুল নিয়মাবলী:\n" +
                    "১. ক্লাসিক বোর্ডে নির্ধারিত পয়েন্টে ম্যাচ।\n" +
                    "২. কোনো প্রকার গাইড হ্যাক বা থার্ড পার্টি টুলস নিষিদ্ধ।\n" +
                    "৩. বিজয়ী স্ক্রিনশট জমা দিন।"
            LUDO -> "🎲 লুডু কিং নিয়মাবলী:\n" +
                    "১. ক্লাসিক বা কুইক মোডে সময়মতো প্রবেশ করুন।\n" +
                    "২. ম্যাচ শেষে উইনিং স্ক্রিনশট সাবমিট করুন।"
            else -> "📋 সাধারণ নিয়মাবলী:\n" +
                    "১. সময়মতো রুমে উপস্থিত থাকুন।\n" +
                    "২. ফেয়ার প্লে বজায় রাখুন এবং ফলাফল স্ক্রিনশট সংরক্ষণ করুন।"
        }
    }
}

@IgnoreExtraProperties
data class WalletTransaction(
    @DocumentId val id: String = "",
    val userId: String = "",
    val userName: String = "",
    val userPhone: String = "",
    val type: String = "ADD_MONEY", // BONUS, ADD_MONEY, WITHDRAW, ENTRY_FEE, PRIZE_WON, ADMIN_ADJUST
    val amount: Double = 0.0,
    val paymentMethod: String = "Bkash", // Bkash, Nagad, AY CITY Wallet, System
    val senderNumber: String = "",
    val receiverNumber: String = "",
    val trxId: String = "",
    val status: String = "PENDING", // PENDING, APPROVED, REJECTED
    val adminNote: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PaymentSettings(
    val bkashNumber: String = "01700000000 (Personal)",
    val nagadNumber: String = "01800000000 (Personal)",
    val rocketNumber: String = "01900000000 (Personal)",
    val whatsappNumber: String = "+8801700000000",
    val telegramLink: String = "https://t.me/AYCITY_DLS",
    val minDeposit: Double = 20.0,
    val minWithdraw: Double = 50.0,
    val notice: String = "বিকাশ বা নগদ পার্সোনাল নাম্বারে সেন্ড মানি করুন। এরপর নিচে TrxID এবং পাঠানো নাম্বার দিন। ৫-১০ মিনিটে ওয়ালেটে ব্যালেন্স জমা হবে।"
)

@IgnoreExtraProperties
data class AppNotice(
    @DocumentId val id: String = "app_notice",
    val title: String = "AY CITY অফিশিয়াল নোটিশ",
    val message: String = "স্বাগতম AY CITY DLS টুর্নামেন্টে! ফেয়ার প্লে বজায় রাখুন এবং লাইভ ম্যাচে অংশগ্রহণ করে জিতে নিন আকর্ষণীয় পুরস্কার।",
    val type: String = "INFO", // INFO, ALERT, UPDATE, EVENT
    val isActive: Boolean = true,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class AdminAlert(
    @DocumentId val id: String = "",
    val type: String = "DEPOSIT", // DEPOSIT, WITHDRAW
    val title: String = "",
    val message: String = "",
    val amount: Double = 0.0,
    val userName: String = "",
    val userPhone: String = "",
    val trxId: String = "",
    val isRead: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null
)

