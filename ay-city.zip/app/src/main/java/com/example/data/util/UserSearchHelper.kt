package com.example.data.util

import android.content.Context
import android.widget.Toast
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

/**
 * Helper object providing user search by UID / name with instant UI callbacks
 * and fallback notifications.
 */
object UserSearchHelper {

    /**
     * Search user by UID, Player UID, or Name in Firestore ("Players" / "Users" collections).
     *
     * @param context Android context for showing toast messages.
     * @param queryText UID, Name, or Phone query to search for.
     * @param onUserFound Callback invoked with the matched user's name and balance.
     * @param onUserNotFound Callback invoked when no user matching the query is found.
     * @param onError Callback invoked on search failure.
     */
    fun searchUser(
        context: Context,
        queryText: String,
        onUserFound: (name: String, balance: Double, user: UserProfile) -> Unit,
        onUserNotFound: () -> Unit = {
            Toast.makeText(context, "কোনো ইউজার পাওয়া যায়নি!", Toast.LENGTH_SHORT).show()
        },
        onError: (String) -> Unit = { errorMsg ->
            Toast.makeText(context, "ত্রুটি: $errorMsg", Toast.LENGTH_SHORT).show()
        }
    ) {
        val q = queryText.trim()
        if (q.isEmpty()) {
            onUserNotFound()
            return
        }

        val db = Firebase.firestore
        val playersRef = db.collection("Players")

        // 1. First attempt: Direct document ID / Auth UID lookup
        playersRef.document(q).get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) {
                    val user = doc.toObject(UserProfile::class.java)
                    val name = doc.getString("name") ?: user?.name ?: "নাম পাওয়া যায়নি"
                    val balance = doc.getDouble("balance") ?: doc.getDouble("walletBalance") ?: user?.balance ?: 0.0
                    val foundUser = (user ?: UserProfile(id = doc.id)).copy(
                        id = doc.id,
                        uid = doc.id,
                        name = name,
                        balance = balance,
                        walletBalance = balance
                    )
                    onUserFound(name, balance, foundUser)
                } else {
                    // 2. Query by 'uid' field
                    playersRef.whereEqualTo("uid", q).get()
                        .addOnSuccessListener { snap ->
                            if (!snap.isEmpty) {
                                val firstDoc = snap.documents.first()
                                val user = firstDoc.toObject(UserProfile::class.java)
                                val name = firstDoc.getString("name") ?: user?.name ?: "নাম পাওয়া যায়নি"
                                val balance = firstDoc.getDouble("balance") ?: firstDoc.getDouble("walletBalance") ?: user?.balance ?: 0.0
                                val foundUser = (user ?: UserProfile(id = firstDoc.id)).copy(
                                    id = firstDoc.id,
                                    uid = firstDoc.id,
                                    name = name,
                                    balance = balance,
                                    walletBalance = balance
                                )
                                onUserFound(name, balance, foundUser)
                            } else {
                                // 3. Query by 'playerUid'
                                playersRef.whereEqualTo("playerUid", q).get()
                                    .addOnSuccessListener { playerSnap ->
                                        if (!playerSnap.isEmpty) {
                                            val firstDoc = playerSnap.documents.first()
                                            val user = firstDoc.toObject(UserProfile::class.java)
                                            val name = firstDoc.getString("name") ?: user?.name ?: "নাম পাওয়া যায়নি"
                                            val balance = firstDoc.getDouble("balance") ?: firstDoc.getDouble("walletBalance") ?: user?.balance ?: 0.0
                                            val foundUser = (user ?: UserProfile(id = firstDoc.id)).copy(
                                                id = firstDoc.id,
                                                uid = firstDoc.id,
                                                name = name,
                                                balance = balance,
                                                walletBalance = balance
                                            )
                                            onUserFound(name, balance, foundUser)
                                        } else {
                                            // 4. Query by uppercase playerUid
                                            playersRef.whereEqualTo("playerUid", q.uppercase()).get()
                                                .addOnSuccessListener { upperSnap ->
                                                    if (!upperSnap.isEmpty) {
                                                        val firstDoc = upperSnap.documents.first()
                                                        val user = firstDoc.toObject(UserProfile::class.java)
                                                        val name = firstDoc.getString("name") ?: user?.name ?: "নাম পাওয়া যায়নি"
                                                        val balance = firstDoc.getDouble("balance") ?: firstDoc.getDouble("walletBalance") ?: user?.balance ?: 0.0
                                                        val foundUser = (user ?: UserProfile(id = firstDoc.id)).copy(
                                                            id = firstDoc.id,
                                                            uid = firstDoc.id,
                                                            name = name,
                                                            balance = balance,
                                                            walletBalance = balance
                                                        )
                                                        onUserFound(name, balance, foundUser)
                                                    } else {
                                                        onUserNotFound()
                                                    }
                                                }
                                                .addOnFailureListener { e -> onError(e.message ?: "Failed") }
                                        }
                                    }
                                    .addOnFailureListener { e -> onError(e.message ?: "Failed") }
                            }
                        }
                        .addOnFailureListener { e -> onError(e.message ?: "Failed") }
                }
            }
            .addOnFailureListener { e -> onError(e.message ?: "Failed") }
    }
}
