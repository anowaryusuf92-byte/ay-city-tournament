package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.model.ADMIN_UID
import com.example.data.model.AdminAlert
import com.example.data.model.AppNotice
import com.example.data.model.PaymentSettings
import com.example.data.model.Participant
import com.example.data.model.Tournament
import com.example.data.model.UserProfile
import com.example.data.model.WalletTransaction
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class AppRepository(
    private val db: FirebaseFirestore
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(FirebaseAppletHelper.getDatabaseId(context))
    )

    private val auth get() = Firebase.auth

    fun getCurrentUserId(): String? = auth.currentUser?.uid

    fun isCurrentUserAdmin(): Boolean = auth.currentUser?.uid == ADMIN_UID

    companion object {
        fun generatePlayerUid(uid: String): String {
            if (uid.isBlank()) {
                val rand = (10000..99999).random()
                return "AY-$rand"
            }
            val positiveHash = Math.abs(uid.hashCode().toLong())
            val number = (positiveHash % 90000L) + 10000L
            return "AY-$number"
        }
    }

    // ----------------------------------------------------
    // User Profile & AY CITY 5 BDT Welcome Bonus in "Players" Collection
    // ----------------------------------------------------
    // ----------------------------------------------------
    // User Profile & Welcome Bonus in "Players" Collection
    // ----------------------------------------------------
    suspend fun ensureUserProfile(
        uid: String,
        email: String,
        displayName: String?,
        photoUrl: String?,
        referralCodeInput: String? = null
    ): UserProfile {
        val playerDocRef = db.collection("Players").document(uid)
        val userDocRef = db.collection("users").document(uid)
        val snapshot = playerDocRef.get().await()

        if (snapshot.exists()) {
            val existing = snapshot.toObject(UserProfile::class.java) ?: UserProfile(id = uid)
            // Ensure walletBalance is present, defaults to 5.0
            val balance = snapshot.getDouble("walletBalance") ?: 5.0
            var playerUid = snapshot.getString("playerUid") ?: existing.playerUid

            // Auto-generate short player UID if missing and backfill to Firestore
            if (playerUid.isBlank()) {
                playerUid = generatePlayerUid(uid)
                playerDocRef.update("playerUid", playerUid)
                userDocRef.set(mapOf("playerUid" to playerUid), com.google.firebase.firestore.SetOptions.merge())
            }

            var referralCode = snapshot.getString("referralCode") ?: existing.referralCode
            if (referralCode.isBlank()) {
                referralCode = playerUid
                playerDocRef.update("referralCode", referralCode)
                userDocRef.set(mapOf("referralCode" to referralCode), com.google.firebase.firestore.SetOptions.merge())
            }

            var updated = existing.copy(
                walletBalance = balance,
                playerUid = playerUid,
                referralCode = referralCode
            )
            // If admin UID, ensure role is admin
            if (uid == ADMIN_UID && existing.role != "admin") {
                playerDocRef.update("role", "admin").await()
                userDocRef.set(mapOf("role" to "admin"), com.google.firebase.firestore.SetOptions.merge())
                updated = updated.copy(role = "admin")
            }
            return updated
        } else {
            // Check for valid referrer using referral code
            var referredById = ""
            if (!referralCodeInput.isNullOrBlank()) {
                val cleanedCode = referralCodeInput.trim()
                try {
                    val querySnap = db.collection("Players")
                        .whereEqualTo("playerUid", cleanedCode)
                        .get().await()
                    if (!querySnap.isEmpty) {
                        val refDoc = querySnap.documents.first()
                        if (refDoc.id != uid) {
                            referredById = refDoc.id
                        }
                    } else {
                        val querySnapUpper = db.collection("Players")
                            .whereEqualTo("playerUid", cleanedCode.uppercase())
                            .get().await()
                        if (!querySnapUpper.isEmpty && querySnapUpper.documents.first().id != uid) {
                            referredById = querySnapUpper.documents.first().id
                        }
                    }
                } catch (e: Exception) {
                    Log.w("AppRepository", "Error resolving referral code: $cleanedCode", e)
                }
            }

            // New player registration -> Grant Instant 5 BDT AY CITY Bonus and assign unique short UID
            val role = if (uid == ADMIN_UID) "admin" else "user"
            val initialBalance = 5.0
            val assignedUid = generatePlayerUid(uid)
            val initialUser = UserProfile(
                id = uid,
                uid = uid,
                playerUid = assignedUid,
                referralCode = assignedUid,
                referredBy = referredById,
                hasActivatedReferral = false,
                name = displayName?.takeIf { it.isNotBlank() } ?: (email.substringBefore("@")),
                email = email,
                phoneNumber = "",
                phone = "",
                photoUrl = photoUrl ?: "",
                dlsTeamName = "",
                walletBalance = initialBalance,
                balance = initialBalance,
                totalMatchesPlayed = 0,
                totalMatchesWon = 0,
                totalPrizeWon = 0.0,
                role = role,
                hasReceivedBonus = true
            )

            // Save player document into "Players" collection
            playerDocRef.set(initialUser).await()
            playerDocRef.update(
                "createdAt", FieldValue.serverTimestamp(),
                "updatedAt", FieldValue.serverTimestamp()
            ).await()

            // Also mirror to "users" and "Users" collection for full compatibility
            userDocRef.set(initialUser).await()
            try {
                db.collection("Users").document(uid).set(initialUser).await()
            } catch (e: Exception) {
                // Secondary mirror fallback
            }

            // Record 5 BDT Welcome Bonus Transaction
            val bonusTx = WalletTransaction(
                userId = uid,
                userName = initialUser.name,
                userPhone = "",
                type = "BONUS",
                amount = 5.0,
                paymentMethod = "DLS Wallet",
                status = "APPROVED",
                adminNote = "Sign-up Welcome Bonus (৳5)"
            )
            val txRef = db.collection("transactions").document()
            txRef.set(bonusTx).await()
            txRef.update("createdAt", FieldValue.serverTimestamp()).await()

            return initialUser
        }
    }

    fun observeUserProfile(uid: String): Flow<UserProfile?> {
        return db.collection("Players").document(uid)
            .snapshots()
            .map { snap ->
                val fallbackUid = generatePlayerUid(uid)
                if (snap.exists()) {
                    val user = snap.toObject(UserProfile::class.java)
                    val balance = snap.getDouble("walletBalance") ?: 5.0
                    val storedUid = snap.getString("playerUid")?.takeIf { it.isNotBlank() }
                        ?: user?.playerUid?.takeIf { it.isNotBlank() }
                        ?: fallbackUid
                    user?.copy(walletBalance = balance, playerUid = storedUid)
                        ?: UserProfile(id = uid, walletBalance = balance, playerUid = storedUid)
                } else {
                    UserProfile(id = uid, walletBalance = 5.0, playerUid = fallbackUid)
                }
            }
    }

    suspend fun updateUserProfile(
        uid: String,
        name: String,
        phone: String,
        dlsTeamName: String,
        photoUrl: String? = null,
        ffInGameName: String? = null,
        ffUid: String? = null
    ): Result<Unit> {
        return try {
            val updates = mutableMapOf<String, Any>(
                "name" to name,
                "phoneNumber" to phone,
                "dlsTeamName" to dlsTeamName,
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (!photoUrl.isNullOrBlank()) {
                updates["photoUrl"] = photoUrl
            }
            if (!ffInGameName.isNullOrBlank()) {
                updates["ffInGameName"] = ffInGameName
            }
            if (!ffUid.isNullOrBlank()) {
                updates["ffUid"] = ffUid
            }
            db.collection("Players").document(uid).set(updates, SetOptions.merge()).await()
            db.collection("users").document(uid).set(updates, SetOptions.merge()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("AppRepository", "Failed to update profile", e)
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // Referral Bonus Activation (Automatic 10 BDT to Referrer)
    // ----------------------------------------------------
    suspend fun activateReferralBonusIfNeeded(userId: String): Result<Unit> {
        return try {
            val userRef = db.collection("Players").document(userId)
            val userSnap = userRef.get().await()
            if (!userSnap.exists()) return Result.success(Unit)

            val hasActivated = userSnap.getBoolean("hasActivatedReferral") ?: false
            val referredBy = userSnap.getString("referredBy") ?: ""

            if (hasActivated || referredBy.isBlank() || referredBy == userId) {
                return Result.success(Unit)
            }

            val referrerRef = db.collection("Players").document(referredBy)
            val txRef = db.collection("transactions").document()

            db.runTransaction { tx ->
                val uSnap = tx.get(userRef)
                val alreadyDone = uSnap.getBoolean("hasActivatedReferral") ?: false
                if (alreadyDone) return@runTransaction

                val rSnap = tx.get(referrerRef)
                if (rSnap.exists()) {
                    val currentBal = rSnap.getDouble("walletBalance") ?: 0.0
                    val newBal = currentBal + 10.0
                    tx.update(referrerRef, "walletBalance", newBal)

                    val referrerUsersRef = db.collection("users").document(referredBy)
                    tx.set(referrerUsersRef, mapOf("walletBalance" to newBal), SetOptions.merge())

                    val bonusTx = WalletTransaction(
                        id = txRef.id,
                        userId = referredBy,
                        userName = rSnap.getString("name") ?: "Referrer",
                        userPhone = rSnap.getString("phoneNumber") ?: "",
                        type = "BONUS",
                        amount = 10.0,
                        paymentMethod = "Referral Reward",
                        status = "APPROVED",
                        adminNote = "৳১০ রেফারেল বোনাস (${uSnap.getString("name") ?: "নতুন ইউজার"} একটিভ হয়েছেন)"
                    )
                    tx.set(txRef, bonusTx)
                }

                tx.update(userRef, "hasActivatedReferral", true)
                val usersDoc = db.collection("users").document(userId)
                tx.set(usersDoc, mapOf("hasActivatedReferral" to true), SetOptions.merge())
            }.await()
            txRef.update("createdAt", FieldValue.serverTimestamp()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("AppRepository", "Failed to activate referral bonus", e)
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // Tournaments
    // ----------------------------------------------------
    fun observeTournaments(
        categoryFilter: String? = null,
        statusFilter: String? = null
    ): Flow<List<Tournament>> {
        return db.collection("tournaments").snapshots().map { snapshot ->
            val list = snapshot.toObjects(Tournament::class.java)
            list.filter { tournament ->
                val matchStatus = statusFilter.isNullOrBlank() || statusFilter == "ALL" || tournament.status == statusFilter
                val matchCategory = categoryFilter.isNullOrBlank() || categoryFilter == "ALL" ||
                    tournament.gameCategory.equals(categoryFilter, ignoreCase = true)
                matchStatus && matchCategory
            }.sortedByDescending { it.createdAt?.seconds ?: 0L }
        }
    }

    fun observeTournament(tournamentId: String): Flow<Tournament?> {
        return db.collection("tournaments").document(tournamentId)
            .snapshots()
            .map { it.toObject(Tournament::class.java) }
    }

    fun observeParticipants(tournamentId: String): Flow<List<Participant>> {
        return db.collection("tournaments").document(tournamentId)
            .collection("participants")
            .snapshots()
            .map { it.toObjects(Participant::class.java) }
    }

    fun isUserJoined(tournamentId: String, uid: String): Flow<Boolean> = callbackFlow {
        val listener = db.collection("tournaments").document(tournamentId)
            .collection("participants").document(uid)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    trySend(false)
                    return@addSnapshotListener
                }
                trySend(snapshot != null && snapshot.exists())
            }
        awaitClose { listener.remove() }
    }

    suspend fun joinTournament(
        tournament: Tournament,
        user: UserProfile,
        dlsTeamName: String,
        phone: String,
        gameUid: String = ""
    ): Result<Unit> {
        val uid = auth.currentUser?.uid ?: return Result.failure(Exception("Not signed in"))

        val isFree = tournament.entryFee <= 0.0

        if (tournament.joinedCount >= tournament.maxSlots) {
            return Result.failure(Exception("Tournament slots are full!"))
        }

        if (!isFree && user.walletBalance < tournament.entryFee) {
            return Result.failure(Exception("পর্যাপ্ত ব্যালেন্স নেই! প্রয়োজন ৳${tournament.entryFee}। ওয়ালেটে টাকা এড করুন।"))
        }

        val tournamentRef = db.collection("tournaments").document(tournament.id)
        val participantRef = tournamentRef.collection("participants").document(uid)
        val userRef = db.collection("Players").document(uid)
        val txRef = db.collection("transactions").document()

        return try {
            db.runTransaction { firestoreTx ->
                val currentTourSnap = firestoreTx.get(tournamentRef)
                val currentJoined = currentTourSnap.getLong("joinedCount")?.toInt() ?: 0
                val maxSlots = currentTourSnap.getLong("maxSlots")?.toInt() ?: 2
                if (currentJoined >= maxSlots) {
                    throw IllegalStateException("Tournament is already full!")
                }

                val currentPartSnap = firestoreTx.get(participantRef)
                if (currentPartSnap.exists()) {
                    throw IllegalStateException("You have already joined this tournament!")
                }

                val userSnap = firestoreTx.get(userRef)
                val balance = userSnap.getDouble("walletBalance") ?: 0.0
                if (!isFree && balance < tournament.entryFee) {
                    throw IllegalStateException("Insufficient balance!")
                }

                // 1. Update user profile (deduct only if tournament has entry fee)
                val matchesPlayed = (userSnap.getLong("totalMatchesPlayed")?.toInt() ?: 0) + 1
                val userUpdates = if (isFree) {
                    mapOf(
                        "totalMatchesPlayed" to matchesPlayed,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                } else {
                    val newBalance = balance - tournament.entryFee
                    mapOf(
                        "walletBalance" to newBalance,
                        "totalMatchesPlayed" to matchesPlayed,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                }
                firestoreTx.set(userRef, userUpdates, SetOptions.merge())

                val usersDocRef = db.collection("users").document(uid)
                firestoreTx.set(usersDocRef, userUpdates, SetOptions.merge())

                // 2. Increment joined count
                firestoreTx.set(tournamentRef, mapOf(
                    "joinedCount" to (currentJoined + 1),
                    "updatedAt" to FieldValue.serverTimestamp()
                ), SetOptions.merge())

                // 3. Add participant
                val participant = Participant(
                    id = uid,
                    userId = uid,
                    userName = user.name,
                    inGameName = dlsTeamName.ifBlank { user.name },
                    dlsTeamName = dlsTeamName.ifBlank { user.dlsTeamName },
                    phoneNumber = phone.ifBlank { user.phoneNumber },
                    slotNumber = currentJoined + 1,
                    gameCategory = tournament.gameCategory,
                    gameUid = gameUid
                )
                firestoreTx.set(participantRef, participant)

                // 4. Record transaction only for paid tournaments
                if (!isFree) {
                    val transaction = WalletTransaction(
                        id = txRef.id,
                        userId = uid,
                        userName = user.name,
                        userPhone = phone,
                        type = "ENTRY_FEE",
                        amount = tournament.entryFee,
                        paymentMethod = "DLS Wallet",
                        status = "APPROVED",
                        adminNote = "Entry fee for: ${tournament.title}"
                    )
                    firestoreTx.set(txRef, transaction)
                }
            }.await()

            // Trigger referral bonus check after user successfully joins their first match
            activateReferralBonusIfNeeded(uid)

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e("AppRepository", "Error joining tournament", e)
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // Admin Tournament Operations
    // ----------------------------------------------------
    suspend fun createTournament(tournament: Tournament): Result<Unit> {
        return try {
            val docRef = db.collection("tournaments").document()
            docRef.set(tournament.copy(id = docRef.id)).await()
            docRef.update(
                "createdAt", FieldValue.serverTimestamp(),
                "updatedAt", FieldValue.serverTimestamp()
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateTournament(tournament: Tournament): Result<Unit> {
        return try {
            db.collection("tournaments").document(tournament.id)
                .set(tournament.copy(updatedAt = null)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateRoomInfo(
        tournamentId: String,
        roomCode: String,
        roomPassword: String,
        status: String
    ): Result<Unit> {
        return try {
            db.collection("tournaments").document(tournamentId).update(
                mapOf(
                    "roomCode" to roomCode,
                    "roomPassword" to roomPassword,
                    "status" to status,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteTournament(tournamentId: String): Result<Unit> {
        return try {
            db.collection("tournaments").document(tournamentId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun declareWinner(
        tournamentId: String,
        winnerId: String,
        winnerName: String,
        prizeAmount: Double
    ): Result<Unit> {
        return try {
            val tournamentRef = db.collection("tournaments").document(tournamentId)
            val userRef = db.collection("Players").document(winnerId)
            val txRef = db.collection("transactions").document()

            db.runTransaction { tx ->
                // Mark tournament completed
                tx.update(tournamentRef, mapOf(
                    "status" to "COMPLETED",
                    "winnerId" to winnerId,
                    "winnerName" to winnerName,
                    "updatedAt" to FieldValue.serverTimestamp()
                ))

                // Credit winner wallet
                val userSnap = tx.get(userRef)
                val currentBal = userSnap.getDouble("walletBalance") ?: 0.0
                val wonMatches = (userSnap.getLong("totalMatchesWon")?.toInt() ?: 0) + 1
                val totalWonPrize = (userSnap.getDouble("totalPrizeWon") ?: 0.0) + prizeAmount

                tx.update(userRef, mapOf(
                    "walletBalance" to (currentBal + prizeAmount),
                    "totalMatchesWon" to wonMatches,
                    "totalPrizeWon" to totalWonPrize,
                    "updatedAt" to FieldValue.serverTimestamp()
                ))

                // Log Prize Won Transaction
                val prizeTx = WalletTransaction(
                    id = txRef.id,
                    userId = winnerId,
                    userName = winnerName,
                    type = "PRIZE_WON",
                    amount = prizeAmount,
                    paymentMethod = "AY CITY Wallet",
                    status = "APPROVED",
                    adminNote = "Prize money won in tournament"
                )
                tx.set(txRef, prizeTx)
            }.await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // Wallet & Transactions
    // ----------------------------------------------------
    fun observeUserTransactions(uid: String): Flow<List<WalletTransaction>> {
        return db.collection("transactions")
            .whereEqualTo("userId", uid)
            .snapshots()
            .map { snap ->
                snap.toObjects(WalletTransaction::class.java)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
    }

    fun observeAllTransactions(): Flow<List<WalletTransaction>> {
        return db.collection("transactions")
            .snapshots()
            .map { snap ->
                snap.toObjects(WalletTransaction::class.java)
                    .sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
    }

    suspend fun requestAddMoney(
        userId: String,
        userName: String,
        userPhone: String,
        method: String,
        senderNumber: String,
        amount: Double,
        trxId: String
    ): Result<Unit> {
        return try {
            val docRef = db.collection("transactions").document()
            val tx = WalletTransaction(
                id = docRef.id,
                userId = userId,
                userName = userName,
                userPhone = userPhone,
                type = "ADD_MONEY",
                amount = amount,
                paymentMethod = method,
                senderNumber = senderNumber,
                trxId = trxId,
                status = "PENDING",
                adminNote = "User submitted Add Money request"
            )
            docRef.set(tx).await()
            docRef.update("createdAt", FieldValue.serverTimestamp()).await()
            try {
                db.collection("deposits").document(docRef.id).set(tx).await()
            } catch (e: Exception) {
                // Secondary collection mirror fallback
            }

            // Real-time notification record for Admin
            try {
                val alert = AdminAlert(
                    id = docRef.id,
                    type = "DEPOSIT",
                    title = "নতুন ডিপোজিট রিকোয়েস্ট (৳$amount)",
                    message = "$userName $method এর মাধ্যমে ৳$amount টাকা এড করতে পাঠিয়েছেন। TrxID: $trxId",
                    amount = amount,
                    userName = userName,
                    userPhone = senderNumber,
                    trxId = trxId,
                    isRead = false
                )
                val alertRef = db.collection("admin_alerts").document(docRef.id)
                alertRef.set(alert).await()
                alertRef.update("createdAt", FieldValue.serverTimestamp()).await()
            } catch (e: Exception) {
                Log.w("AppRepository", "Failed to dispatch admin deposit alert", e)
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun requestWithdraw(
        userId: String,
        userName: String,
        userPhone: String,
        method: String,
        receiverNumber: String,
        amount: Double
    ): Result<Unit> {
        val userRef = db.collection("Players").document(userId)
        val txRef = db.collection("transactions").document()

        return try {
            db.runTransaction { tx ->
                val userSnap = tx.get(userRef)
                val currentBal = userSnap.getDouble("walletBalance") ?: 0.0
                if (currentBal < amount) {
                    throw IllegalStateException("Insufficient balance for withdrawal!")
                }

                // Deduct from balance upfront so user cannot double spend
                tx.update(userRef, "walletBalance", currentBal - amount)

                val withdrawTx = WalletTransaction(
                    id = txRef.id,
                    userId = userId,
                    userName = userName,
                    userPhone = userPhone,
                    type = "WITHDRAW",
                    amount = amount,
                    paymentMethod = method,
                    receiverNumber = receiverNumber,
                    status = "PENDING",
                    adminNote = "Pending admin transfer"
                )
                tx.set(txRef, withdrawTx)
            }.await()
            txRef.update("createdAt", FieldValue.serverTimestamp()).await()

            // Real-time notification record for Admin
            try {
                val alert = AdminAlert(
                    id = txRef.id,
                    type = "WITHDRAW",
                    title = "নতুন উইথড্র রিকোয়েস্ট (৳$amount)",
                    message = "$userName $method এর মাধ্যমে ৳$amount টাকা ক্যাশআউট পাঠিয়েছেন। নাম্বার: $receiverNumber",
                    amount = amount,
                    userName = userName,
                    userPhone = receiverNumber,
                    isRead = false
                )
                val alertRef = db.collection("admin_alerts").document(txRef.id)
                alertRef.set(alert).await()
                alertRef.update("createdAt", FieldValue.serverTimestamp()).await()
            } catch (e: Exception) {
                Log.w("AppRepository", "Failed to dispatch admin withdraw alert", e)
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun observeAdminAlerts(): Flow<List<AdminAlert>> {
        return db.collection("admin_alerts")
            .snapshots()
            .map { snap ->
                snap.toObjects(AdminAlert::class.java).sortedByDescending { it.createdAt?.seconds ?: 0L }
            }
    }

    suspend fun markAlertAsRead(alertId: String): Result<Unit> {
        return try {
            db.collection("admin_alerts").document(alertId)
                .set(mapOf("isRead" to true), SetOptions.merge()).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun approveAddMoney(transaction: WalletTransaction): Result<Unit> {
        return try {
            val userRef = db.collection("Players").document(transaction.userId)
            val txRef = db.collection("transactions").document(transaction.id)

            db.runTransaction { tx ->
                val userSnap = tx.get(userRef)
                val currentBal = userSnap.getDouble("walletBalance") ?: userSnap.getDouble("balance") ?: 0.0
                val newBal = currentBal + transaction.amount
                tx.update(userRef, "walletBalance", newBal)
                tx.update(userRef, "balance", newBal)
                tx.update(txRef, mapOf(
                    "status" to "APPROVED",
                    "adminNote" to "Approved by Admin"
                ))
            }.await()

            try {
                db.collection("users").document(transaction.userId).update(
                    mapOf("walletBalance" to FieldValue.increment(transaction.amount),
                          "balance" to FieldValue.increment(transaction.amount))
                )
                db.collection("Users").document(transaction.userId).update(
                    mapOf("walletBalance" to FieldValue.increment(transaction.amount),
                          "balance" to FieldValue.increment(transaction.amount))
                )
            } catch (e: Exception) {}

            // Trigger referral bonus check when user activates account via their approved deposit
            activateReferralBonusIfNeeded(transaction.userId)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun rejectAddMoney(transaction: WalletTransaction, reason: String): Result<Unit> {
        return try {
            db.collection("transactions").document(transaction.id).update(
                mapOf(
                    "status" to "REJECTED",
                    "adminNote" to reason.ifBlank { "Rejected by Admin" }
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun approveWithdraw(transaction: WalletTransaction): Result<Unit> {
        return try {
            db.collection("transactions").document(transaction.id).update(
                mapOf(
                    "status" to "APPROVED",
                    "adminNote" to "Payment completed by Admin"
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun rejectWithdraw(transaction: WalletTransaction, reason: String): Result<Unit> {
        return try {
            val userRef = db.collection("Players").document(transaction.userId)
            val txRef = db.collection("transactions").document(transaction.id)

            db.runTransaction { tx ->
                // Refund deducted amount back to user's wallet
                val userSnap = tx.get(userRef)
                val currentBal = userSnap.getDouble("walletBalance") ?: userSnap.getDouble("balance") ?: 0.0
                val newBal = currentBal + transaction.amount
                tx.update(userRef, "walletBalance", newBal)
                tx.update(userRef, "balance", newBal)
                tx.update(txRef, mapOf(
                    "status" to "REJECTED",
                    "adminNote" to reason.ifBlank { "Rejected & Refunded by Admin" }
                ))
            }.await()

            try {
                db.collection("users").document(transaction.userId).update(
                    mapOf("walletBalance" to FieldValue.increment(transaction.amount),
                          "balance" to FieldValue.increment(transaction.amount))
                )
                db.collection("Users").document(transaction.userId).update(
                    mapOf("walletBalance" to FieldValue.increment(transaction.amount),
                          "balance" to FieldValue.increment(transaction.amount))
                )
            } catch (e: Exception) {}

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun adminAdjustUserWallet(
        targetUserId: String,
        amountDelta: Double,
        reason: String
    ): Result<Unit> {
        return try {
            val userRef = db.collection("Players").document(targetUserId)
            val txRef = db.collection("transactions").document()

            db.runTransaction { tx ->
                val userSnap = tx.get(userRef)
                val currentBal = userSnap.getDouble("walletBalance") ?: userSnap.getDouble("balance") ?: 0.0
                val newBal = (currentBal + amountDelta).coerceAtLeast(0.0)
                tx.update(userRef, "walletBalance", newBal)
                tx.update(userRef, "balance", newBal)

                val adjustTx = WalletTransaction(
                    id = txRef.id,
                    userId = targetUserId,
                    userName = userSnap.getString("name") ?: "Player",
                    type = "ADMIN_ADJUST",
                    amount = amountDelta,
                    paymentMethod = "AY CITY Admin",
                    status = "APPROVED",
                    adminNote = reason.ifBlank { "Admin manual wallet adjustment" }
                )
                tx.set(txRef, adjustTx)
            }.await()
            txRef.update("createdAt", FieldValue.serverTimestamp()).await()

            try {
                db.collection("users").document(targetUserId).update(
                    mapOf("walletBalance" to FieldValue.increment(amountDelta),
                          "balance" to FieldValue.increment(amountDelta))
                )
                db.collection("Users").document(targetUserId).update(
                    mapOf("walletBalance" to FieldValue.increment(amountDelta),
                          "balance" to FieldValue.increment(amountDelta))
                )
            } catch (e: Exception) {}

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun observeAllUsers(): Flow<List<UserProfile>> {
        return db.collection("Players")
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc ->
                    val user = doc.toObject(UserProfile::class.java) ?: UserProfile(id = doc.id)
                    val effectiveId = doc.id
                    val effectiveUid = doc.getString("uid")?.takeIf { it.isNotBlank() } ?: effectiveId
                    val effectiveBal = doc.getDouble("balance") ?: doc.getDouble("walletBalance") ?: user.walletBalance
                    val effectivePhone = doc.getString("phone") ?: doc.getString("phoneNumber") ?: user.phoneNumber
                    val effectivePlayerUid = doc.getString("playerUid")?.takeIf { it.isNotBlank() }
                        ?: user.playerUid.takeIf { it.isNotBlank() }
                        ?: generatePlayerUid(effectiveId)

                    user.copy(
                        id = effectiveId,
                        uid = effectiveUid,
                        playerUid = effectivePlayerUid,
                        walletBalance = effectiveBal,
                        balance = effectiveBal,
                        phoneNumber = effectivePhone,
                        phone = effectivePhone
                    )
                }
            }
    }

    suspend fun searchUserDirect(queryText: String): Result<List<UserProfile>> {
        return try {
            val q = queryText.trim()
            if (q.isBlank()) return Result.success(emptyList())

            val results = mutableMapOf<String, UserProfile>()

            // 1. Direct Document ID / Auth UID in "Players"
            val directDoc = db.collection("Players").document(q).get().await()
            if (directDoc.exists()) {
                val user = directDoc.toObject(UserProfile::class.java)
                val bal = directDoc.getDouble("balance") ?: directDoc.getDouble("walletBalance") ?: 0.0
                val mapped = (user ?: UserProfile(id = directDoc.id)).copy(
                    id = directDoc.id,
                    uid = directDoc.id,
                    balance = bal,
                    walletBalance = bal
                )
                results[mapped.id] = mapped
            }

            // 2. Query by 'uid'
            val uidSnap = db.collection("Players").whereEqualTo("uid", q).get().await()
            for (doc in uidSnap.documents) {
                val user = doc.toObject(UserProfile::class.java)
                val bal = doc.getDouble("balance") ?: doc.getDouble("walletBalance") ?: 0.0
                val mapped = (user ?: UserProfile(id = doc.id)).copy(
                    id = doc.id,
                    uid = doc.id,
                    balance = bal,
                    walletBalance = bal
                )
                results[mapped.id] = mapped
            }

            // 3. Query by 'playerUid'
            val playerUidSnap = db.collection("Players").whereEqualTo("playerUid", q).get().await()
            for (doc in playerUidSnap.documents) {
                val user = doc.toObject(UserProfile::class.java)
                val bal = doc.getDouble("balance") ?: doc.getDouble("walletBalance") ?: 0.0
                val mapped = (user ?: UserProfile(id = doc.id)).copy(
                    id = doc.id,
                    uid = doc.id,
                    balance = bal,
                    walletBalance = bal
                )
                results[mapped.id] = mapped
            }

            // 4. Query by uppercase playerUid
            val playerUidUpperSnap = db.collection("Players").whereEqualTo("playerUid", q.uppercase()).get().await()
            for (doc in playerUidUpperSnap.documents) {
                val user = doc.toObject(UserProfile::class.java)
                val bal = doc.getDouble("balance") ?: doc.getDouble("walletBalance") ?: 0.0
                val mapped = (user ?: UserProfile(id = doc.id)).copy(
                    id = doc.id,
                    uid = doc.id,
                    balance = bal,
                    walletBalance = bal
                )
                results[mapped.id] = mapped
            }

            Result.success(results.values.toList())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // Settings (Payment numbers, notice)
    // ----------------------------------------------------
    fun observePaymentSettings(): Flow<PaymentSettings> {
        return db.collection("settings").document("payment_info")
            .snapshots()
            .map { snap ->
                snap.toObject(PaymentSettings::class.java) ?: PaymentSettings()
            }
    }

    suspend fun updatePaymentSettings(settings: PaymentSettings): Result<Unit> {
        return try {
            db.collection("settings").document("payment_info")
                .set(settings)
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ----------------------------------------------------
    // App Notice Board / Broadcast Announcements
    // ----------------------------------------------------
    fun observeAppNotice(): Flow<AppNotice> {
        return db.collection("settings").document("app_notice")
            .snapshots()
            .map { snap ->
                snap.toObject(AppNotice::class.java) ?: AppNotice()
            }
    }

    suspend fun updateAppNotice(notice: AppNotice): Result<Unit> {
        return try {
            db.collection("settings").document("app_notice")
                .set(notice, SetOptions.merge())
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

object FirebaseAppletHelper {
    fun getDatabaseId(context: Context): String {
        return try {
            val resId = context.resources.getIdentifier("firestore_database_id", "string", context.packageName)
            if (resId != 0) context.getString(resId) else "(default)"
        } catch (e: Exception) {
            "(default)"
        }
    }
}
