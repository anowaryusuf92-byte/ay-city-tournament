package com.example.data.util

import android.content.Context

object NotificationHelper {
    fun showNotification(context: Context, title: String, message: String) {
        com.example.util.NotificationHelper.showNotification(context, title, message)
    }
}
