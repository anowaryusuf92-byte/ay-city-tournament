package com.example.ui.wallet

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NorthEast
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PriceCheck
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentSettings
import com.example.data.model.UserProfile
import com.example.data.model.WalletTransaction
import com.example.data.repository.AppRepository
import com.example.ui.theme.AyBkashPink
import com.example.ui.theme.AyCyan
import com.example.ui.theme.AyDarkBackground
import com.example.ui.theme.AyEmerald
import com.example.ui.theme.AyGold
import com.example.ui.theme.AyNagadOrange
import com.example.ui.theme.AyPitchBlack
import com.example.ui.theme.AyRed
import com.example.ui.theme.AySurfaceBorder
import com.example.ui.theme.AySurfaceCard
import com.example.ui.theme.AySurfaceCardElevated
import com.example.ui.theme.AyTextMuted
import com.example.ui.theme.AyTextPrimary
import com.example.ui.theme.AyTextSecondary
import kotlinx.coroutines.launch

@Composable
fun WalletScreen(
    repository: AppRepository,
    currentUser: UserProfile?
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current

    val activeUid = (currentUser?.id ?: repository.getCurrentUserId()) ?: ""
    val liveProfile by repository.observeUserProfile(activeUid).collectAsState(initial = currentUser)
    val currentBalance = liveProfile?.walletBalance ?: (currentUser?.walletBalance ?: 5.0)

    val transactions by repository.observeUserTransactions(activeUid)
        .collectAsState(initial = emptyList())
    val paymentSettings by repository.observePaymentSettings()
        .collectAsState(initial = PaymentSettings())

    var showAddMoneyDialog by remember { mutableStateOf(false) }
    var showWithdrawDialog by remember { mutableStateOf(false) }

    // Add Money State
    var selectedMethod by remember { mutableStateOf("Bkash") }
    var senderPhone by remember(liveProfile) { mutableStateOf(liveProfile?.phoneNumber ?: currentUser?.phoneNumber ?: "") }
    var addAmount by remember { mutableStateOf("") }
    var trxId by remember { mutableStateOf("") }
    var isSubmittingDeposit by remember { mutableStateOf(false) }

    // Withdraw State
    var withdrawMethod by remember { mutableStateOf("Bkash") }
    var receiverPhone by remember { mutableStateOf(currentUser?.phoneNumber ?: "") }
    var withdrawAmount by remember { mutableStateOf("") }
    var isSubmittingWithdraw by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Hero Wallet Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    Brush.horizontalGradient(listOf(AyGold, AyEmerald)),
                    RoundedCornerShape(20.dp)
                ),
            colors = CardDefaults.cardColors(containerColor = AySurfaceCard),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                AyGold.copy(alpha = 0.08f),
                                Color.Transparent
                            )
                        )
                    )
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(AyGold.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                tint = AyGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "AY CITY ওয়ালেট ব্যালেন্স",
                            color = AyTextSecondary,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    // Bonus Badge
                    Box(
                        modifier = Modifier
                            .background(AyEmerald.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = null, tint = AyGold, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "৳৫ সাইন-আপ বোনাস",
                                color = AyGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Big Balance
                Text(
                    text = "৳ ${"%.2f".format(currentBalance)}",
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Black,
                    color = AyGold
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Quick Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { showAddMoneyDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AyEmerald,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("টাকা এড করুন", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Button(
                        onClick = { showWithdrawDialog = true },
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AySurfaceCardElevated,
                            contentColor = AyGold
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = androidx.compose.ui.graphics.SolidColor(AyGold.copy(alpha = 0.5f))
                        )
                    ) {
                        Icon(Icons.Default.NorthEast, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("টাকা তুলুন", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Wallet Limits & Processing Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    AySurfaceBorder,
                    RoundedCornerShape(14.dp)
                ),
            colors = CardDefaults.cardColors(containerColor = AySurfaceCard),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "লেনদেন সীমা ও প্রসেসিং (Limits & Policy)",
                        color = AyTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "স্বয়ংক্রিয় যাচাই",
                        color = AyEmerald,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Min Deposit Box
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(AySurfaceCardElevated, RoundedCornerShape(10.dp))
                            .border(1.dp, AyEmerald.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                            .padding(vertical = 8.dp, horizontal = 10.dp)
                    ) {
                        Column {
                            Text("মিনিমাম ডিপোজিট", color = AyTextMuted, fontSize = 10.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "৳${paymentSettings.minDeposit.toInt()}",
                                color = AyEmerald,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Min Withdraw Box
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(AySurfaceCardElevated, RoundedCornerShape(10.dp))
                            .border(1.dp, AyGold.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                            .padding(vertical = 8.dp, horizontal = 10.dp)
                    ) {
                        Column {
                            Text("মিনিমাম উইথড্র", color = AyTextMuted, fontSize = 10.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "৳${paymentSettings.minWithdraw.toInt()}",
                                color = AyGold,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Processing Time Box
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(AySurfaceCardElevated, RoundedCornerShape(10.dp))
                            .border(1.dp, AyCyan.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                            .padding(vertical = 8.dp, horizontal = 10.dp)
                    ) {
                        Column {
                            Text("প্রসেসিং সময়", color = AyTextMuted, fontSize = 10.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "৫-৩০ মি.",
                                color = AyCyan,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Transaction History Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.History, contentDescription = null, tint = AyGold, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "লেনদেনের ইতিহাস (Transactions)",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = AyTextPrimary
                )
            }
            Text(
                text = "${transactions.size} টি রেকর্ড",
                color = AyTextMuted,
                fontSize = 12.sp
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (transactions.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "এখনও কোনো লেনদেন সম্পন্ন হয়নি",
                    color = AyTextMuted,
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(transactions, key = { it.id }) { tx ->
                    TransactionItemCard(tx = tx)
                }
            }
        }
    }

    // Add Money Dialog
    if (showAddMoneyDialog) {
        val targetNumber = if (selectedMethod == "Bkash") paymentSettings.bkashNumber else paymentSettings.nagadNumber

        AlertDialog(
            onDismissRequest = { if (!isSubmittingDeposit) showAddMoneyDialog = false },
            containerColor = AySurfaceCard,
            title = {
                Text("টাকা এড করুন (Add Money)", color = AyGold, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Text(
                        text = "পেমেন্ট মেথড নির্বাচন করুন:",
                        color = AyTextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { selectedMethod = "Bkash" },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedMethod == "Bkash") AyBkashPink else AySurfaceCardElevated,
                                contentColor = Color.White
                            )
                        ) {
                            Text("বিকাশ (bKash)")
                        }

                        Button(
                            onClick = { selectedMethod = "Nagad" },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selectedMethod == "Nagad") AyNagadOrange else AySurfaceCardElevated,
                                contentColor = Color.White
                            )
                        ) {
                            Text("নগদ (Nagad)")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Admin Number Display
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = AySurfaceCardElevated),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("$selectedMethod নাম্বার (সেন্ড মানি করুন):", color = AyTextMuted, fontSize = 11.sp)
                                Text(targetNumber, color = AyGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            IconButton(
                                onClick = {
                                    val cleanNum = targetNumber.substringBefore(" ")
                                    clipboardManager.setText(AnnotatedString(cleanNum))
                                    Toast.makeText(context, "$selectedMethod নাম্বার কপি হয়েছে!", Toast.LENGTH_SHORT).show()
                                }
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = AyGold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Min Deposit Notice Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = AyEmerald.copy(alpha = 0.12f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = AyEmerald, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "মিনিমাম ডিপোজিট: ৳${paymentSettings.minDeposit.toInt()} (Min Deposit: ৳${paymentSettings.minDeposit.toInt()})",
                                color = AyEmerald,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = senderPhone,
                        onValueChange = { senderPhone = it },
                        label = { Text("যে নাম্বার থেকে পাঠিয়েছেন") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AyGold,
                            unfocusedBorderColor = AySurfaceBorder,
                            focusedTextColor = AyTextPrimary,
                            unfocusedTextColor = AyTextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = addAmount,
                        onValueChange = { addAmount = it },
                        label = { Text("টাকার পরিমাণ (মিনিমাম ৳${paymentSettings.minDeposit.toInt()})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AyGold,
                            unfocusedBorderColor = AySurfaceBorder,
                            focusedTextColor = AyTextPrimary,
                            unfocusedTextColor = AyTextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = trxId,
                        onValueChange = { trxId = it },
                        label = { Text("ট্রানজেকশন আইডি (TrxID)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AyGold,
                            unfocusedBorderColor = AySurfaceBorder,
                            focusedTextColor = AyTextPrimary,
                            unfocusedTextColor = AyTextPrimary
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amountVal = addAmount.toDoubleOrNull() ?: 0.0
                        val minDeposit = paymentSettings.minDeposit
                        if (amountVal < minDeposit) {
                            Toast.makeText(context, "সর্বনিম্ন ডিপোজিট ৳${minDeposit.toInt()} (Min Deposit: ৳${minDeposit.toInt()})", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (senderPhone.isBlank() || trxId.isBlank()) {
                            Toast.makeText(context, "সকল তথ্য সঠিকভাবে পূরণ করুন", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        isSubmittingDeposit = true
                        scope.launch {
                            currentUser?.let { user ->
                                val res = repository.requestAddMoney(
                                    userId = user.id,
                                    userName = user.name,
                                    userPhone = user.phoneNumber,
                                    method = selectedMethod,
                                    senderNumber = senderPhone.trim(),
                                    amount = amountVal,
                                    trxId = trxId.trim().uppercase()
                                )
                                if (res.isSuccess) {
                                    Toast.makeText(context, "টাকা এড রিকোয়েস্ট সাবমিট হয়েছে! যাচাই শেষে ব্যালেন্স জমা হবে।", Toast.LENGTH_LONG).show()
                                    showAddMoneyDialog = false
                                    addAmount = ""
                                    trxId = ""
                                } else {
                                    Toast.makeText(context, res.exceptionOrNull()?.message ?: "ব্যর্থ হয়েছে", Toast.LENGTH_SHORT).show()
                                }
                            }
                            isSubmittingDeposit = false
                        }
                    },
                    enabled = !isSubmittingDeposit,
                    colors = ButtonDefaults.buttonColors(containerColor = AyEmerald, contentColor = Color.White)
                ) {
                    if (isSubmittingDeposit) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                    } else {
                        Text("রিকোয়েস্ট পাঠান", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddMoneyDialog = false }, enabled = !isSubmittingDeposit) {
                    Text("বাতিল", color = AyTextMuted)
                }
            }
        )
    }

    // Withdraw Dialog
    if (showWithdrawDialog) {
        val userBalance = currentBalance
        val minWithdraw = paymentSettings.minWithdraw

        AlertDialog(
            onDismissRequest = { if (!isSubmittingWithdraw) showWithdrawDialog = false },
            containerColor = AySurfaceCard,
            title = {
                Text("টাকা তুলুন (Withdraw)", color = AyGold, fontWeight = FontWeight.Bold)
            },
            text = {
                Column {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AySurfaceCardElevated, RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("উত্তোলনযোগ্য ব্যালেন্স:", color = AyTextMuted, fontSize = 12.sp)
                        Text("৳${"%.2f".format(userBalance)}", color = AyGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Min Cashout Notice Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = AyGold.copy(alpha = 0.12f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = AyGold, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "মিনিমাম ক্যাশআউট: ৳${minWithdraw.toInt()} (Min Cashout: ৳${minWithdraw.toInt()})",
                                color = AyGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("পেমেন্ট মেথড নির্বাচন করুন:", color = AyTextSecondary, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { withdrawMethod = "Bkash" },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (withdrawMethod == "Bkash") AyBkashPink else AySurfaceCardElevated,
                                contentColor = Color.White
                            )
                        ) {
                            Text("বিকাশ")
                        }

                        Button(
                            onClick = { withdrawMethod = "Nagad" },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (withdrawMethod == "Nagad") AyNagadOrange else AySurfaceCardElevated,
                                contentColor = Color.White
                            )
                        ) {
                            Text("নগদ")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = receiverPhone,
                        onValueChange = { receiverPhone = it },
                        label = { Text("$withdrawMethod নাম্বার") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AyGold,
                            unfocusedBorderColor = AySurfaceBorder,
                            focusedTextColor = AyTextPrimary,
                            unfocusedTextColor = AyTextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = withdrawAmount,
                        onValueChange = { withdrawAmount = it },
                        label = { Text("উত্তোলনের পরিমাণ (মিনিমাম ৳${minWithdraw.toInt()})") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AyGold,
                            unfocusedBorderColor = AySurfaceBorder,
                            focusedTextColor = AyTextPrimary,
                            unfocusedTextColor = AyTextPrimary
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amountVal = withdrawAmount.toDoubleOrNull() ?: 0.0
                        if (amountVal < minWithdraw) {
                            Toast.makeText(context, "সর্বনিম্ন ৳${minWithdraw.toInt()} উত্তোলন করা যাবে (Min Withdraw: ৳${minWithdraw.toInt()})", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (amountVal > userBalance) {
                            Toast.makeText(context, "ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        if (receiverPhone.isBlank()) {
                            Toast.makeText(context, "রিসিভার নাম্বার দিন", Toast.LENGTH_SHORT).show()
                            return@Button
                        }

                        isSubmittingWithdraw = true
                        scope.launch {
                            currentUser?.let { user ->
                                val res = repository.requestWithdraw(
                                    userId = user.id,
                                    userName = user.name,
                                    userPhone = user.phoneNumber,
                                    method = withdrawMethod,
                                    receiverNumber = receiverPhone.trim(),
                                    amount = amountVal
                                )
                                if (res.isSuccess) {
                                    Toast.makeText(context, "উইথড্র রিকোয়েস্ট জমা হয়েছে!", Toast.LENGTH_LONG).show()
                                    showWithdrawDialog = false
                                    withdrawAmount = ""
                                } else {
                                    Toast.makeText(context, res.exceptionOrNull()?.message ?: "ব্যর্থ হয়েছে", Toast.LENGTH_SHORT).show()
                                }
                            }
                            isSubmittingWithdraw = false
                        }
                    },
                    enabled = !isSubmittingWithdraw,
                    colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
                ) {
                    if (isSubmittingWithdraw) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = AyPitchBlack)
                    } else {
                        Text("উইথড্র কনফার্ম করুন", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showWithdrawDialog = false }, enabled = !isSubmittingWithdraw) {
                    Text("বাতিল", color = AyTextMuted)
                }
            }
        )
    }
}

@Composable
fun TransactionItemCard(tx: WalletTransaction) {
    val isCredit = tx.type in listOf("BONUS", "ADD_MONEY", "PRIZE_WON")

    val icon = when (tx.type) {
        "BONUS" -> Icons.Default.Star
        "ADD_MONEY" -> Icons.Default.ArrowDownward
        "WITHDRAW" -> Icons.Default.ArrowUpward
        "ENTRY_FEE" -> Icons.Default.SportsSoccer
        "PRIZE_WON" -> Icons.Default.EmojiEvents
        else -> Icons.Default.PriceCheck
    }

    val typeTitle = when (tx.type) {
        "BONUS" -> "AY CITY সাইন-আপ বোনাস"
        "ADD_MONEY" -> "টাকা ডিপোজিট (${tx.paymentMethod})"
        "WITHDRAW" -> "টাকা উইথড্র (${tx.paymentMethod})"
        "ENTRY_FEE" -> "টুর্নামেন্ট এন্ট্রি ফি"
        "PRIZE_WON" -> "টুর্নামেন্ট প্রাইজ বিজয়ী"
        else -> "ওয়ালেট এডজাস্টমেন্ট"
    }

    val statusColor = when (tx.status) {
        "APPROVED" -> AyEmerald
        "REJECTED" -> AyRed
        else -> AyGold
    }

    val statusLabel = when (tx.status) {
        "APPROVED" -> "সফল (Approved)"
        "REJECTED" -> "বাতিল (Rejected)"
        else -> "পেন্ডিং (Pending)"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, AySurfaceBorder, RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(containerColor = AySurfaceCardElevated),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .background(
                            if (isCredit) AyEmerald.copy(alpha = 0.15f) else AyRed.copy(alpha = 0.15f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isCredit) AyEmerald else AyRed,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = typeTitle,
                        fontWeight = FontWeight.Bold,
                        color = AyTextPrimary,
                        fontSize = 13.sp
                    )

                    if (tx.trxId.isNotBlank()) {
                        Text(
                            text = "TrxID: ${tx.trxId}",
                            color = AyTextMuted,
                            fontSize = 11.sp
                        )
                    }

                    if (tx.adminNote.isNotBlank()) {
                        Text(
                            text = tx.adminNote,
                            color = AyTextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${if (isCredit) "+" else "-"}৳${"%.2f".format(tx.amount)}",
                    fontWeight = FontWeight.Black,
                    color = if (isCredit) AyEmerald else AyRed,
                    fontSize = 15.sp
                )

                Spacer(modifier = Modifier.height(2.dp))

                Box(
                    modifier = Modifier
                        .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = statusLabel,
                        color = statusColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}
