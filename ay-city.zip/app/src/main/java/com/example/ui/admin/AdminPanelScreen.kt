package com.example.ui.admin

import android.content.Context
import android.media.AudioManager
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PriceCheck
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import com.example.data.model.AppNotice
import com.example.data.model.GameCategories
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ADMIN_UID
import com.example.data.model.Participant
import com.example.data.model.PaymentSettings
import com.example.data.model.Tournament
import com.example.data.model.UserProfile
import com.example.data.model.WalletTransaction
import com.example.data.repository.AppRepository
import com.example.ui.theme.AyBkashPink
import com.example.ui.theme.AyCyan
import com.example.ui.theme.AyDarkBackground
import com.example.ui.theme.AyEmerald
import com.example.ui.theme.AyGold
import com.example.ui.theme.AyNagadOrange
import com.example.ui.theme.AyPitchBlack
import com.example.ui.theme.AyRed
import com.example.ui.theme.AySurfaceBorder
import com.example.ui.theme.AySurfaceCard
import com.example.ui.theme.AySurfaceCardElevated
import com.example.ui.theme.AyTextMuted
import com.example.ui.theme.AyTextPrimary
import com.example.ui.theme.AyTextSecondary
import kotlinx.coroutines.launch

fun playAdminAlertSound(context: Context) {
    try {
        val notificationUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val ringtone = RingtoneManager.getRingtone(context, notificationUri)
        ringtone?.play()
    } catch (e: Exception) {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
            toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 350)
        } catch (e2: Exception) {
            // Audio fallback
        }
    }
}

fun triggerAdminVibration(context: Context) {
    try {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createOneShot(350, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(350)
        }
    } catch (e: Exception) {
        // Vibration fallback
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminPanelScreen(
    repository: AppRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val currentUid = repository.getCurrentUserId()

    // Verification check for Admin UID
    if (currentUid != ADMIN_UID) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = AyRed, modifier = Modifier.size(64.dp))
            Spacer(modifier = Modifier.height(16.dp))
            Text("এক্সেস ডিনাইড (Access Denied)", color = AyRed, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(8.dp))
            Text("শুধুমাত্র নির্দিষ্ট Admin UID এই প্যানেল এক্সেস করতে পারবে।", color = AyTextSecondary, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(20.dp))
            Button(onClick = onBack, colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)) {
                Text("ফিরে যান")
            }
        }
        return
    }

    val allTransactions by repository.observeAllTransactions().collectAsState(initial = emptyList())
    val pendingDeposits = remember(allTransactions) { allTransactions.filter { it.type == "ADD_MONEY" && it.status == "PENDING" } }
    val pendingWithdrawals = remember(allTransactions) { allTransactions.filter { it.type == "WITHDRAW" && it.status == "PENDING" } }
    val totalPending = pendingDeposits.size + pendingWithdrawals.size

    var isSoundEnabled by remember { mutableStateOf(true) }
    var previousPendingCount by remember { mutableIntStateOf(-1) }

    LaunchedEffect(totalPending) {
        if (previousPendingCount != -1 && totalPending > previousPendingCount && isSoundEnabled) {
            playAdminAlertSound(context)
            triggerAdminVibration(context)
            Toast.makeText(context, "🔔 নতুন ট্রানজেকশন রিকোয়েস্ট এসেছে!", Toast.LENGTH_SHORT).show()
        }
        previousPendingCount = totalPending
    }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        "📊 ড্যাশবোর্ড",
        "🏆 টুর্নামেন্ট",
        if (pendingDeposits.isNotEmpty()) "📥 ডিপোজিট (${pendingDeposits.size})" else "📥 ডিপোজিট",
        if (pendingWithdrawals.isNotEmpty()) "📤 উইথড্র (${pendingWithdrawals.size})" else "📤 উইথড্র",
        "👥 ওয়ালেট",
        "⚙️ সেটিংস"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(AyDarkBackground)
    ) {
        // Admin Top Bar
        TopAppBar(
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = AyGold, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("DLS TOURNAMENT এডমিন প্যানেল", color = AyGold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                        Text("UID: ${ADMIN_UID.take(8)}...", color = AyTextMuted, fontSize = 10.sp)
                    }
                }
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = AyTextPrimary)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = AySurfaceCard)
        )

        // Real-time Pending Transactions Alert Bar
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .clickable {
                    if (pendingDeposits.isNotEmpty()) selectedTabIndex = 2
                    else if (pendingWithdrawals.isNotEmpty()) selectedTabIndex = 3
                },
            colors = CardDefaults.cardColors(
                containerColor = if (totalPending > 0) AyRed.copy(alpha = 0.2f) else AySurfaceCard
            ),
            border = BorderStroke(
                1.dp,
                if (totalPending > 0) AyRed else AySurfaceBorder
            ),
            shape = RoundedCornerShape(10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (totalPending > 0) Icons.Default.NotificationsActive else Icons.Default.NotificationsNone,
                        contentDescription = null,
                        tint = if (totalPending > 0) AyRed else AyTextMuted,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = if (totalPending > 0) "⚡ $totalPending টি পেন্ডিং রিকোয়েস্ট অপেক্ষমান" else "কোনো পেন্ডিং ট্রানজেকশন নেই (সব ক্লিয়ার)",
                            color = if (totalPending > 0) AyTextPrimary else AyTextMuted,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "ডিপোজিট: ${pendingDeposits.size} | উইথড্র: ${pendingWithdrawals.size}",
                            color = if (totalPending > 0) AyGold else AyTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Test Sound Button
                    IconButton(
                        onClick = {
                            playAdminAlertSound(context)
                            triggerAdminVibration(context)
                            Toast.makeText(context, "অ্যালার্ট সাউন্ড টেস্ট ✓", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolumeUp,
                            contentDescription = "Test Sound",
                            tint = AyGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Toggle Sound
                    IconButton(
                        onClick = {
                            isSoundEnabled = !isSoundEnabled
                            Toast.makeText(
                                context,
                                if (isSoundEnabled) "অ্যালার্ট সাউন্ড চালু করা হয়েছে" else "অ্যালার্ট সাউন্ড বন্ধ করা হয়েছে",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isSoundEnabled) Icons.Default.Notifications else Icons.Default.NotificationsOff,
                            contentDescription = "Toggle Sound",
                            tint = if (isSoundEnabled) AyEmerald else AyTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Scrollable Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = AySurfaceCard,
            contentColor = AyGold,
            edgePadding = 12.dp,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                    color = AyGold
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                            color = if (selectedTabIndex == index) AyGold else AyTextMuted,
                            fontSize = 12.sp
                        )
                    }
                )
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(16.dp)
        ) {
            when (selectedTabIndex) {
                0 -> AdminStatsDashboardTab(repository)
                1 -> AdminTournamentsTab(repository)
                2 -> AdminDepositRequestsTab(repository)
                3 -> AdminWithdrawRequestsTab(repository)
                4 -> AdminUserWalletsTab(repository)
                5 -> AdminSettingsTab(repository)
            }
        }
    }
}

// -------------------------------------------------------------------------
// Tab 0: Platform Analytics & Live Stats Dashboard
// -------------------------------------------------------------------------
@Composable
fun AdminStatsDashboardTab(repository: AppRepository) {
    val allUsers by repository.observeAllUsers().collectAsState(initial = emptyList())
    val allTransactions by repository.observeAllTransactions().collectAsState(initial = emptyList())
    val allTournaments by repository.observeTournaments().collectAsState(initial = emptyList())

    val totalUsersCount = allUsers.size
    val totalUserWalletsBalance = allUsers.sumOf { it.walletBalance }
    val totalMatchesPlayed = allUsers.sumOf { it.totalMatchesPlayed }
    val totalMatchesWon = allUsers.sumOf { it.totalMatchesWon }
    val totalMatchesLost = (totalMatchesPlayed - totalMatchesWon).coerceAtLeast(0)
    val winRate = if (totalMatchesPlayed > 0) {
        "%.1f%%".format((totalMatchesWon.toDouble() / totalMatchesPlayed.toDouble()) * 100)
    } else "0.0%"

    val totalDeposits = allTransactions.filter { it.type == "ADD_MONEY" && it.status == "APPROVED" }.sumOf { it.amount }
    val totalWithdrawals = allTransactions.filter { it.type == "WITHDRAW" && it.status == "APPROVED" }.sumOf { it.amount }
    val totalEntryFees = allTransactions.filter { it.type == "ENTRY_FEE" && it.status == "APPROVED" }.sumOf { it.amount }
    val totalPrizeDistributed = allTournaments.filter { it.status == "COMPLETED" }.sumOf { it.prizePool }

    val netRevenue = totalDeposits - totalWithdrawals

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "📊 প্ল্যাটফর্ম সার্বিক অ্যানালিটিক্স ও কাউন্টার",
            color = AyGold,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
        Text(
            text = "রিয়েল-টাইম হিসাব: ব্যালেন্স, মোট খরচ, প্রফিট এবং Win/Loss স্বয়ংক্রিয় ট্র্যাকিং",
            color = AyTextSecondary,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Row 1: Users & Wallets
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = AySurfaceCardElevated),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.People, contentDescription = null, tint = AyCyan, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("মোট প্লেয়ার", color = AyTextMuted, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("$totalUsersCount জন", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("নিবন্ধিত প্লেয়ার", color = AyTextMuted, fontSize = 10.sp)
                }
            }

            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = AySurfaceCardElevated),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = AyGold, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("প্লেয়ার মোট ব্যালেন্স", color = AyTextMuted, fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("৳${"%.2f".format(totalUserWalletsBalance)}", color = AyGold, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("ইউজার ওয়ালেটে জমা", color = AyTextMuted, fontSize = 10.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Financial Overview Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = AySurfaceCardElevated),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("💰 আর্থিক হিসাব ও প্রফিট মার্জিন", color = AyGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("মোট ডিপোজিট (ইনকাম)", color = AyTextMuted, fontSize = 11.sp)
                        Text("+৳${"%.2f".format(totalDeposits)}", color = AyEmerald, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("মোট উইথড্র (খরচ)", color = AyTextMuted, fontSize = 11.sp)
                        Text("-৳${"%.2f".format(totalWithdrawals)}", color = AyRed, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = AySurfaceBorder, thickness = 1.dp)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("এন্ট্রি ফি সংগ্রহ", color = AyTextMuted, fontSize = 11.sp)
                        Text("৳${"%.2f".format(totalEntryFees)}", color = AyCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("বিতরণকৃত প্রাইজ পুল", color = AyTextMuted, fontSize = 11.sp)
                        Text("৳${"%.2f".format(totalPrizeDistributed)}", color = AyGold, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (netRevenue >= 0) AyEmerald.copy(alpha = 0.15f) else AyRed.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (netRevenue >= 0) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                                contentDescription = null,
                                tint = if (netRevenue >= 0) AyEmerald else AyRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("নিট প্রফিট / ব্যালেন্স মার্জিন", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                        Text(
                            text = "৳${"%.2f".format(netRevenue)}",
                            color = if (netRevenue >= 0) AyEmerald else AyRed,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Gameplay Win / Loss Counter Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = AySurfaceCardElevated),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("🎮 গেমপ্লে ও Win/Loss ট্র্যাকিং কাউন্টার", color = AyCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("মোট ম্যাচ খেলা হয়েছে", color = AyTextMuted, fontSize = 11.sp)
                        Text("$totalMatchesPlayed টি ম্যাচ", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("মোট জয় (Wins)", color = AyTextMuted, fontSize = 11.sp)
                        Text("$totalMatchesWon ✓", color = AyEmerald, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("মোট হার (Losses)", color = AyTextMuted, fontSize = 11.sp)
                        Text("$totalMatchesLost ✕", color = AyRed, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AySurfaceCard, RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("প্লেয়ারদের সামগ্রিক উইন রেট:", color = AyTextSecondary, fontSize = 11.sp)
                    Text(winRate, color = AyGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val upcomingCount = allTournaments.count { it.status == "UPCOMING" }
                    val liveCount = allTournaments.count { it.status == "LIVE" }
                    val completedCount = allTournaments.count { it.status == "COMPLETED" }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(AySurfaceCard, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text("আসন্ন", color = AyGold, fontSize = 10.sp)
                            Text("$upcomingCount টি", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(AySurfaceCard, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text("লাইভ", color = AyEmerald, fontSize = 10.sp)
                            Text("$liveCount টি", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(AySurfaceCard, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text("সমাপ্ত", color = AyTextMuted, fontSize = 10.sp)
                            Text("$completedCount টি", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------
// Tab 1: Tournaments Management
// -------------------------------------------------------------------------
@Composable
fun AdminTournamentsTab(repository: AppRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tournaments by repository.observeTournaments().collectAsState(initial = emptyList())

    var showCreateDialog by remember { mutableStateOf(false) }
    var editingRoomTournament by remember { mutableStateOf<Tournament?>(null) }
    var declaringWinnerTournament by remember { mutableStateOf<Tournament?>(null) }

    // Create Tournament Fields
    var title by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(GameCategories.DLS) }
    var matchType by remember { mutableStateOf("1v1 Classic") }
    var mapType by remember { mutableStateOf("Bermuda") }
    var entryFee by remember { mutableStateOf("10") }
    var prizePool by remember { mutableStateOf("100") }
    var maxSlots by remember { mutableStateOf("2") }
    var matchTime by remember { mutableStateOf("আজ রাত ৯:০০ টা") }
    var rules by remember { mutableStateOf(GameCategories.getDefaultRules(GameCategories.DLS)) }
    var isCreating by remember { mutableStateOf(false) }

    // Room ID Fields
    var roomCodeInput by remember { mutableStateOf("") }
    var roomPassInput by remember { mutableStateOf("") }
    var roomStatusInput by remember { mutableStateOf("LIVE") }
    var isUpdatingRoom by remember { mutableStateOf(false) }

    // Winner Selection
    var selectedWinnerId by remember { mutableStateOf("") }
    var selectedWinnerName by remember { mutableStateOf("") }
    var isDeclaringWinner by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        Button(
            onClick = { showCreateDialog = true },
            modifier = Modifier.fillMaxWidth().height(46.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(modifier = Modifier.width(6.dp))
            Text("+ নতুন টুর্নামেন্ট তৈরি করুন", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(14.dp))

        if (tournaments.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("কোনো টুর্নামেন্ট নেই। নতুন তৈরি করুন।", color = AyTextMuted)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(tournaments, key = { it.id }) { tour ->
                    Card(
                        modifier = Modifier.fillMaxWidth().border(1.dp, AySurfaceBorder, RoundedCornerShape(12.dp)),
                        colors = CardDefaults.cardColors(containerColor = AySurfaceCard)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(tour.title, color = AyTextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Box(
                                    modifier = Modifier
                                        .background(
                                            when (tour.status) {
                                                "LIVE" -> AyEmerald.copy(alpha = 0.2f)
                                                "COMPLETED" -> AyTextMuted.copy(alpha = 0.2f)
                                                else -> AyGold.copy(alpha = 0.2f)
                                            },
                                            RoundedCornerShape(6.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(tour.status, color = if (tour.status == "LIVE") AyEmerald else AyGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text("এন্ট্রি ফি: ৳${tour.entryFee} | প্রাইজ: ৳${tour.prizePool} | স্লট: ${tour.joinedCount}/${tour.maxSlots}", color = AyTextSecondary, fontSize = 12.sp)

                            if (tour.roomCode.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("রুম কোড: ${tour.roomCode} (পাস: ${tour.roomPassword})", color = AyCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            if (tour.winnerName.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("বিজয়ী: ${tour.winnerName}", color = AyGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        editingRoomTournament = tour
                                        roomCodeInput = tour.roomCode
                                        roomPassInput = tour.roomPassword
                                        roomStatusInput = if (tour.status == "UPCOMING") "LIVE" else tour.status
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AyGold),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(AyGold))
                                ) {
                                    Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("রুম আইডি", fontSize = 11.sp)
                                }

                                OutlinedButton(
                                    onClick = { declaringWinnerTournament = tour },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AyEmerald),
                                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(AyEmerald))
                                ) {
                                    Icon(Icons.Default.EmojiEvents, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("বিজয়ী ঘোষণা", fontSize = 11.sp)
                                }

                                IconButton(
                                    onClick = {
                                        scope.launch {
                                            repository.deleteTournament(tour.id)
                                            Toast.makeText(context, "টুর্নামেন্ট মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AyRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Create Tournament Dialog
    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { if (!isCreating) showCreateDialog = false },
            containerColor = AySurfaceCard,
            title = { Text("নতুন টুর্নামেন্ট তৈরি করুন", color = AyGold, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text("১. গেম ক্যাটাগরি নির্বাচন করুন:", color = AyGold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(listOf(GameCategories.DLS, GameCategories.FREE_FIRE, GameCategories.EFOOTBALL, GameCategories.CARROM, GameCategories.LUDO)) { cat ->
                            val isSelected = selectedCategory == cat
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedCategory = cat
                                    rules = GameCategories.getDefaultRules(cat)
                                    if (cat == GameCategories.FREE_FIRE) {
                                        matchType = "1v1 Custom"
                                        maxSlots = "2"
                                    } else if (cat == GameCategories.DLS) {
                                        matchType = "1v1 Classic"
                                        maxSlots = "2"
                                    } else {
                                        matchType = "1v1 Match"
                                        maxSlots = "2"
                                    }
                                },
                                label = { Text(cat, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AyGold,
                                    selectedLabelColor = AyPitchBlack,
                                    containerColor = AySurfaceCardElevated,
                                    labelColor = AyTextSecondary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("টুর্নামেন্টের নাম (Title)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("২. ম্যাচের ধরন ও মোড:", color = AyGold, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    val presetOptions = if (selectedCategory == GameCategories.FREE_FIRE) {
                        listOf(
                            "1v1 Custom" to "2",
                            "2v2 Custom" to "4",
                            "3v3 Custom" to "6",
                            "4v4 Clash Squad" to "8",
                            "Full Map Bermuda" to "48"
                        )
                    } else if (selectedCategory == GameCategories.DLS) {
                        listOf(
                            "1v1 Classic" to "2",
                            "1v1 Friendly" to "2",
                            "16 Player Cup" to "16"
                        )
                    } else {
                        listOf(
                            "1v1 Match" to "2",
                            "Multiplayer" to "4"
                        )
                    }

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(presetOptions) { (typeOption, slotCount) ->
                            FilterChip(
                                selected = matchType == typeOption,
                                onClick = {
                                    matchType = typeOption
                                    maxSlots = slotCount
                                },
                                label = { Text(typeOption, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AyGold,
                                    selectedLabelColor = AyPitchBlack,
                                    containerColor = AySurfaceCardElevated,
                                    labelColor = AyTextSecondary
                                )
                            )
                        }
                    }

                    if (selectedCategory == GameCategories.FREE_FIRE) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("ম্যাপ নির্বাচন:", color = AyTextSecondary, fontSize = 11.sp)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(listOf("Bermuda", "Purgatory", "Kalahari", "NextEra")) { m ->
                                FilterChip(
                                    selected = mapType == m,
                                    onClick = { mapType = m },
                                    label = { Text(m, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = AyCyan,
                                        selectedLabelColor = AyPitchBlack,
                                        containerColor = AySurfaceCardElevated,
                                        labelColor = AyTextSecondary
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = matchType,
                        onValueChange = {
                            matchType = it
                            if (it.contains("1v1", ignoreCase = true)) {
                                maxSlots = "2"
                            }
                        },
                        label = { Text("কাস্টম মোড নাম") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = entryFee,
                            onValueChange = { entryFee = it },
                            label = { Text("এন্ট্রি ফি (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                        )
                        OutlinedTextField(
                            value = prizePool,
                            onValueChange = { prizePool = it },
                            label = { Text("পুরস্কার (৳)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = maxSlots,
                            onValueChange = { maxSlots = it },
                            label = { Text("সর্বোচ্চ স্লট (Slots)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                        )
                        OutlinedTextField(
                            value = matchTime,
                            onValueChange = { matchTime = it },
                            label = { Text("ম্যাচের সময়") },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rules,
                        onValueChange = { rules = it },
                        label = { Text("নিয়মাবলী (Rules)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (title.isBlank()) {
                            Toast.makeText(context, "টুর্নামেন্টের নাম দিন", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        isCreating = true
                        scope.launch {
                            val is1v1 = matchType.contains("1v1", ignoreCase = true)
                            val finalSlots = if (is1v1) 2 else (maxSlots.toIntOrNull() ?: 2)
                            val tour = Tournament(
                                title = title.trim(),
                                gameCategory = selectedCategory,
                                matchType = matchType.trim(),
                                mapType = if (selectedCategory == GameCategories.FREE_FIRE) mapType else "Default",
                                entryFee = entryFee.toDoubleOrNull() ?: 0.0,
                                prizePool = prizePool.toDoubleOrNull() ?: 0.0,
                                maxSlots = finalSlots,
                                matchTime = matchTime.trim(),
                                rules = rules.trim(),
                                status = "UPCOMING"
                            )
                            val res = repository.createTournament(tour)
                            if (res.isSuccess) {
                                Toast.makeText(context, "টুর্নামেন্ট তৈরি সফল হয়েছে!", Toast.LENGTH_SHORT).show()
                                showCreateDialog = false
                                title = ""
                            }
                            isCreating = false
                        }
                    },
                    enabled = !isCreating,
                    colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
                ) {
                    Text("তৈরি করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("বাতিল", color = AyTextMuted) }
            }
        )
    }

    // Room ID & Password Update Dialog
    if (editingRoomTournament != null) {
        val tour = editingRoomTournament!!
        AlertDialog(
            onDismissRequest = { if (!isUpdatingRoom) editingRoomTournament = null },
            containerColor = AySurfaceCard,
            title = { Text("রুম আইডি ও পাসওয়ার্ড আপডেট", color = AyGold, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(tour.title, color = AyTextPrimary, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = roomCodeInput,
                        onValueChange = { roomCodeInput = it },
                        label = { Text("DLS রুম কোড (যেমন: AY-9021)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = roomPassInput,
                        onValueChange = { roomPassInput = it },
                        label = { Text("পাসওয়ার্ড (ঐচ্ছিক)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("টুর্নামেন্ট স্ট্যাটাস:", color = AyTextSecondary, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("UPCOMING", "LIVE", "COMPLETED").forEach { st ->
                            FilterChip(
                                selected = roomStatusInput == st,
                                onClick = { roomStatusInput = st },
                                label = { Text(st, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        isUpdatingRoom = true
                        scope.launch {
                            repository.updateRoomInfo(
                                tournamentId = tour.id,
                                roomCode = roomCodeInput.trim(),
                                roomPassword = roomPassInput.trim(),
                                status = roomStatusInput
                            )
                            Toast.makeText(context, "রুম তথ্য আপডেট হয়েছে!", Toast.LENGTH_SHORT).show()
                            editingRoomTournament = null
                            isUpdatingRoom = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
                ) {
                    Text("সেভ করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingRoomTournament = null }) { Text("বাতিল", color = AyTextMuted) }
            }
        )
    }

    // Declare Winner Dialog
    if (declaringWinnerTournament != null) {
        val tour = declaringWinnerTournament!!
        val participants by repository.observeParticipants(tour.id).collectAsState(initial = emptyList())

        AlertDialog(
            onDismissRequest = { if (!isDeclaringWinner) declaringWinnerTournament = null },
            containerColor = AySurfaceCard,
            title = { Text("টুর্নামেন্টের বিজয়ী নির্বাচন করুন", color = AyGold, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("টুর্নামেন্ট: ${tour.title}", color = AyTextPrimary, fontWeight = FontWeight.Bold)
                    Text("বিজয়ী প্রাইজ: ৳${tour.prizePool} (স্বয়ংক্রিয়ভাবে বিজয়ীর ওয়ালেটে জমা হবে)", color = AyEmerald, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(12.dp))

                    if (participants.isEmpty()) {
                        Text("এই টুর্নামেন্টে এখনও কোনো প্লেয়ার জয়েন করেনি।", color = AyTextMuted)
                    } else {
                        Text("অংশগ্রহণকারীদের তালিকা থেকে বিজয়ী নির্বাচন করুন:", color = AyTextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        LazyColumn(modifier = Modifier.height(180.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(participants) { part ->
                                val isSelected = selectedWinnerId == part.userId
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedWinnerId = part.userId
                                            selectedWinnerName = "${part.userName} (${part.dlsTeamName})"
                                        }
                                        .border(1.dp, if (isSelected) AyGold else AySurfaceBorder, RoundedCornerShape(8.dp)),
                                    colors = CardDefaults.cardColors(containerColor = if (isSelected) AyGold.copy(alpha = 0.2f) else AySurfaceCardElevated)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(part.userName, color = AyTextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                            Text("টিম: ${part.dlsTeamName} | স্লট: #${part.slotNumber}", color = AyTextMuted, fontSize = 11.sp)
                                        }
                                        if (isSelected) {
                                            Icon(Icons.Default.Check, contentDescription = null, tint = AyGold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (participants.isNotEmpty()) {
                    Button(
                        onClick = {
                            if (selectedWinnerId.isBlank()) {
                                Toast.makeText(context, "বিজয়ী নির্বাচন করুন", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isDeclaringWinner = true
                            scope.launch {
                                val res = repository.declareWinner(
                                    tournamentId = tour.id,
                                    winnerId = selectedWinnerId,
                                    winnerName = selectedWinnerName,
                                    prizeAmount = tour.prizePool
                                )
                                if (res.isSuccess) {
                                    Toast.makeText(context, "বিজয়ী ঘোষণা সম্পন্ন এবং ওয়ালেটে ৳${tour.prizePool} যোগ হয়েছে!", Toast.LENGTH_LONG).show()
                                    declaringWinnerTournament = null
                                    selectedWinnerId = ""
                                    selectedWinnerName = ""
                                }
                                isDeclaringWinner = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
                    ) {
                        Text("বিজয়ী ঘোষণা ও প্রাইজ প্রদান")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { declaringWinnerTournament = null }) { Text("বাতিল", color = AyTextMuted) }
            }
        )
    }
}

// -------------------------------------------------------------------------
// Tab 2: Deposit (Add Money) Requests
// -------------------------------------------------------------------------
@Composable
fun AdminDepositRequestsTab(repository: AppRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val allTransactions by repository.observeAllTransactions().collectAsState(initial = emptyList())
    val depositRequests = allTransactions.filter { it.type == "ADD_MONEY" }
    var processingTxId by remember { mutableStateOf<String?>(null) }

    if (depositRequests.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("কোনো টাকা এড রিকোয়েস্ট নেই", color = AyTextMuted)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(depositRequests, key = { it.id }) { tx ->
                val isProcessingThis = processingTxId == tx.id
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, AySurfaceBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = AySurfaceCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${tx.userName} (${tx.paymentMethod})", color = AyTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("+৳${tx.amount}", color = AyEmerald, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("প্রেরক নাম্বার: ${tx.senderNumber}", color = AyTextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            if (tx.senderNumber.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(tx.senderNumber))
                                        Toast.makeText(context, "নাম্বার কপি হয়েছে", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy Phone", tint = AyTextSecondary, modifier = Modifier.size(14.dp))
                                }
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("TrxID: ${tx.trxId}", color = AyGold, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            if (tx.trxId.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(tx.trxId))
                                        Toast.makeText(context, "TrxID কপি হয়েছে: ${tx.trxId}", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy TrxID", tint = AyGold, modifier = Modifier.size(15.dp))
                                }
                            }
                        }

                        Text("স্ট্যাটাস: ${tx.status}", color = if (tx.status == "APPROVED") AyEmerald else if (tx.status == "REJECTED") AyRed else AyGold, fontSize = 11.sp)

                        if (tx.status == "PENDING") {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = {
                                        processingTxId = tx.id
                                        scope.launch {
                                            try {
                                                repository.approveAddMoney(tx)
                                                Toast.makeText(context, "টাকা এড অনুমোদন হয়েছে!", Toast.LENGTH_SHORT).show()
                                            } finally {
                                                processingTxId = null
                                            }
                                        }
                                    },
                                    enabled = processingTxId == null,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = AyEmerald, contentColor = Color.White)
                                ) {
                                    if (isProcessingThis) {
                                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                    } else {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("অনুমোদন (Approve)")
                                    }
                                }

                                Button(
                                    onClick = {
                                        processingTxId = tx.id
                                        scope.launch {
                                            try {
                                                repository.rejectAddMoney(tx, "ভুল TrxID বা টাকা পাওয়া যায়নি")
                                                Toast.makeText(context, "রিকোয়েস্ট বাতিল করা হয়েছে", Toast.LENGTH_SHORT).show()
                                            } finally {
                                                processingTxId = null
                                            }
                                        }
                                    },
                                    enabled = processingTxId == null,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = AyRed.copy(alpha = 0.2f), contentColor = AyRed)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("বাতিল (Reject)")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------
// Tab 3: Withdraw Requests
// -------------------------------------------------------------------------
@Composable
fun AdminWithdrawRequestsTab(repository: AppRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val allTransactions by repository.observeAllTransactions().collectAsState(initial = emptyList())
    val withdrawRequests = allTransactions.filter { it.type == "WITHDRAW" }
    var processingTxId by remember { mutableStateOf<String?>(null) }

    if (withdrawRequests.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("কোনো উইথড্র রিকোয়েস্ট নেই", color = AyTextMuted)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(withdrawRequests, key = { it.id }) { tx ->
                val isProcessingThis = processingTxId == tx.id
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, AySurfaceBorder, RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = AySurfaceCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${tx.userName} (${tx.paymentMethod})", color = AyTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("-৳${tx.amount}", color = AyRed, fontWeight = FontWeight.Black, fontSize = 16.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("টাকা পাঠানোর নাম্বার: ${tx.receiverNumber}", color = AyGold, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            if (tx.receiverNumber.isNotBlank()) {
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(tx.receiverNumber))
                                        Toast.makeText(context, "নাম্বার কপি হয়েছে: ${tx.receiverNumber}", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy Phone", tint = AyGold, modifier = Modifier.size(15.dp))
                                }
                            }
                        }
                        Text("স্ট্যাটাস: ${tx.status}", color = if (tx.status == "APPROVED") AyEmerald else if (tx.status == "REJECTED") AyRed else AyGold, fontSize = 11.sp)

                        if (tx.status == "PENDING") {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = {
                                        processingTxId = tx.id
                                        scope.launch {
                                            try {
                                                repository.approveWithdraw(tx)
                                                Toast.makeText(context, "উইথড্র সম্পন্ন হিসেবে মার্ক করা হয়েছে!", Toast.LENGTH_SHORT).show()
                                            } finally {
                                                processingTxId = null
                                            }
                                        }
                                    },
                                    enabled = processingTxId == null,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = AyEmerald, contentColor = Color.White)
                                ) {
                                    if (isProcessingThis) {
                                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                                    } else {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("পেইড (Approve)")
                                    }
                                }

                                Button(
                                    onClick = {
                                        processingTxId = tx.id
                                        scope.launch {
                                            try {
                                                repository.rejectWithdraw(tx, "ভুল নাম্বার বা একাউন্ট সীমাবদ্ধতা (টাকা ফেরত দেয়া হলো)")
                                                Toast.makeText(context, "উইথড্র বাতিল এবং ব্যালেন্স রিফান্ড হয়েছে", Toast.LENGTH_SHORT).show()
                                            } finally {
                                                processingTxId = null
                                            }
                                        }
                                    },
                                    enabled = processingTxId == null,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = AyRed.copy(alpha = 0.2f), contentColor = AyRed)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("বাতিল ও রিফান্ড")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------------------
// Tab 4: User Wallets Management
// -------------------------------------------------------------------------
@Composable
fun AdminUserWalletsTab(repository: AppRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val users by repository.observeAllUsers().collectAsState(initial = emptyList())

    var searchQuery by remember { mutableStateOf("") }
    var adjustingUser by remember { mutableStateOf<UserProfile?>(null) }
    var adjustAmount by remember { mutableStateOf("") }
    var isAddingFunds by remember { mutableStateOf(true) } // true: Add, false: Subtract
    var adjustReason by remember { mutableStateOf("Admin adjustment") }
    var directSearchedUsers by remember { mutableStateOf<List<UserProfile>>(emptyList()) }

    val q = searchQuery.trim()

    // Real-time server-side query fallback when local list has no match
    LaunchedEffect(q) {
        if (q.isNotEmpty()) {
            val result = repository.searchUserDirect(q)
            if (result.isSuccess) {
                directSearchedUsers = result.getOrDefault(emptyList())
            }
        } else {
            directSearchedUsers = emptyList()
        }
    }

    // Combine local reactive users and direct query results
    val allCombinedUsers = remember(users, directSearchedUsers) {
        val map = linkedMapOf<String, UserProfile>()
        users.forEach { map[it.id] = it }
        directSearchedUsers.forEach { map[it.id] = it }
        map.values.toList()
    }

    val filteredUsers = remember(q, allCombinedUsers) {
        if (q.isBlank()) allCombinedUsers else {
            allCombinedUsers.filter {
                it.playerUid.contains(q, ignoreCase = true) ||
                it.uid.contains(q, ignoreCase = true) ||
                it.id.contains(q, ignoreCase = true) ||
                it.name.contains(q, ignoreCase = true) ||
                it.email.contains(q, ignoreCase = true) ||
                it.phoneNumber.contains(q, ignoreCase = true) ||
                it.phone.contains(q, ignoreCase = true) ||
                it.dlsTeamName.contains(q, ignoreCase = true) ||
                it.ffInGameName.contains(q, ignoreCase = true) ||
                it.ffUid.contains(q, ignoreCase = true) ||
                it.referralCode.contains(q, ignoreCase = true)
            }
        }
    }

    val topMatchedUser = if (q.isNotEmpty() && filteredUsers.isNotEmpty()) filteredUsers.first() else null

    Column(modifier = Modifier.fillMaxSize()) {
        // Search Input Box (searchEditText)
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("ইউজার সার্চ (UID, নাম, ইমেইল, টিম, ফোন)") },
            placeholder = { Text("যেমন: AY-12345 বা 017xxxxxxxx", color = AyTextMuted) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AyGold) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear Search", tint = AyTextMuted)
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = AyGold,
                unfocusedBorderColor = AySurfaceBorder,
                focusedTextColor = AyTextPrimary,
                unfocusedTextColor = AyTextPrimary
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Instant Live Result Section (tvUserName & tvUserBalance display right below search box)
        if (q.isNotEmpty()) {
            if (topMatchedUser != null) {
                val effectiveBal = if (topMatchedUser.balance > 0.0) topMatchedUser.balance else topMatchedUser.walletBalance
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .border(1.dp, AyGold.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = AySurfaceCardElevated)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "নাম: ${topMatchedUser.name.ifBlank { "নাম পাওয়া যায়নি" }}",
                                color = AyTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            Text(
                                text = "ব্যালেন্স: ৳ ${"%.2f".format(effectiveBal)}",
                                color = AyGold,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val displayUid = topMatchedUser.playerUid.ifBlank { AppRepository.generatePlayerUid(topMatchedUser.id) }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(AyGold.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("UID: $displayUid", color = AyGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                IconButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(topMatchedUser.id))
                                        Toast.makeText(context, "Auth UID কপি হয়েছে!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy UID", tint = AyGold, modifier = Modifier.size(14.dp))
                                }
                            }

                            Button(
                                onClick = {
                                    adjustingUser = topMatchedUser
                                    adjustAmount = ""
                                },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("ওয়ালেট এডজাস্ট", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            } else {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                        .border(1.dp, AyRed.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                    colors = CardDefaults.cardColors(containerColor = AySurfaceCard)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ইউজার পাওয়া যায়নি",
                                color = AyRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "",
                                color = AyTextMuted,
                                fontSize = 12.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "প্রদত্ত UID, নাম, বা ফোন নম্বরের সাথে কোনো ইউজারের মিল মেলেনি।",
                            color = AyTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(filteredUsers, key = { it.id }) { user ->
                Card(
                    modifier = Modifier.fillMaxWidth().border(1.dp, AySurfaceBorder, RoundedCornerShape(10.dp)),
                    colors = CardDefaults.cardColors(containerColor = AySurfaceCard)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(user.name, fontWeight = FontWeight.Bold, color = AyTextPrimary, fontSize = 14.sp)
                                Spacer(modifier = Modifier.width(6.dp))
                                val displayUid = user.playerUid.ifBlank { AppRepository.generatePlayerUid(user.id) }
                                Box(
                                    modifier = Modifier
                                        .background(AyGold.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("UID: $displayUid", color = AyGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text(user.email, color = AyTextMuted, fontSize = 11.sp)
                            if (user.phoneNumber.isNotBlank()) {
                                Text("ফোন: ${user.phoneNumber}", color = AyTextSecondary, fontSize = 11.sp)
                            }
                            if (user.dlsTeamName.isNotBlank()) {
                                Text("টিম: ${user.dlsTeamName}", color = AyCyan, fontSize = 11.sp)
                            }
                            if (user.ffInGameName.isNotBlank() || user.ffUid.isNotBlank()) {
                                Text("FF: ${user.ffInGameName} (${user.ffUid})", color = AyEmerald, fontSize = 11.sp)
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            val userBal = if (user.balance > 0.0) user.balance else user.walletBalance
                            Text("৳${"%.2f".format(userBal)}", fontWeight = FontWeight.Black, color = AyGold, fontSize = 15.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Button(
                                onClick = {
                                    adjustingUser = user
                                    adjustAmount = ""
                                },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = AyGold.copy(alpha = 0.2f), contentColor = AyGold)
                            ) {
                                Text("ওয়ালেট এডজাস্ট", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // Adjust Wallet Dialog
    if (adjustingUser != null) {
        val user = adjustingUser!!
        AlertDialog(
            onDismissRequest = { adjustingUser = null },
            containerColor = AySurfaceCard,
            title = { Text("ওয়ালেট ব্যালেন্স নিয়ন্ত্রণ", color = AyGold, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("ইউজার: ${user.name}", color = AyTextPrimary, fontWeight = FontWeight.Bold)
                    Text("বর্তমান ব্যালেন্স: ৳${user.walletBalance}", color = AyGold, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { isAddingFunds = true },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (isAddingFunds) AyEmerald else AySurfaceCardElevated, contentColor = Color.White)
                        ) {
                            Text("+ টাকা যোগ")
                        }

                        Button(
                            onClick = { isAddingFunds = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (!isAddingFunds) AyRed else AySurfaceCardElevated, contentColor = Color.White)
                        ) {
                            Text("- টাকা বিয়োগ")
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = adjustAmount,
                        onValueChange = { adjustAmount = it },
                        label = { Text("টাকার পরিমাণ (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = adjustReason,
                        onValueChange = { adjustReason = it },
                        label = { Text("কারণ / নোট") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = adjustAmount.toDoubleOrNull() ?: 0.0
                        if (amount <= 0.0) {
                            Toast.makeText(context, "সঠিক পরিমাণ দিন", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        val delta = if (isAddingFunds) amount else -amount
                        scope.launch {
                            repository.adminAdjustUserWallet(user.id, delta, adjustReason.trim())
                            Toast.makeText(context, "ব্যালেন্স আপডেট সম্পন্ন হয়েছে!", Toast.LENGTH_SHORT).show()
                            adjustingUser = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
                ) {
                    Text("কনফার্ম করুন")
                }
            },
            dismissButton = {
                TextButton(onClick = { adjustingUser = null }) { Text("বাতিল", color = AyTextMuted) }
            }
        )
    }
}

// -------------------------------------------------------------------------
// Tab 5: Settings (Payment numbers, notice)
// -------------------------------------------------------------------------
@Composable
fun AdminSettingsTab(repository: AppRepository) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by repository.observePaymentSettings().collectAsState(initial = PaymentSettings())
    val appNotice by repository.observeAppNotice().collectAsState(initial = AppNotice())

    var bkashNum by remember(settings) { mutableStateOf(settings.bkashNumber) }
    var nagadNum by remember(settings) { mutableStateOf(settings.nagadNumber) }
    var rocketNum by remember(settings) { mutableStateOf(settings.rocketNumber) }
    var waNum by remember(settings) { mutableStateOf(settings.whatsappNumber) }
    var tgLink by remember(settings) { mutableStateOf(settings.telegramLink) }
    var minDeposit by remember(settings) { mutableStateOf(settings.minDeposit.toString()) }
    var minWithdraw by remember(settings) { mutableStateOf(settings.minWithdraw.toString()) }
    var notice by remember(settings) { mutableStateOf(settings.notice) }
    var isSaving by remember { mutableStateOf(false) }

    var noticeTitle by remember(appNotice) { mutableStateOf(appNotice.title) }
    var noticeMessage by remember(appNotice) { mutableStateOf(appNotice.message) }
    var noticeType by remember(appNotice) { mutableStateOf(appNotice.type) }
    var isNoticeActive by remember(appNotice) { mutableStateOf(appNotice.isActive) }
    var isSavingNotice by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // App Notice Board Admin Section
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, AyGold.copy(alpha = 0.5f), RoundedCornerShape(14.dp)),
            colors = CardDefaults.cardColors(containerColor = AySurfaceCardElevated),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Campaign, contentDescription = null, tint = AyGold, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("📢 হোম পেজ নোটিশ বোর্ড", color = AyGold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (isNoticeActive) "সক্রিয় (Active)" else "বন্ধ (Inactive)", color = if (isNoticeActive) AyEmerald else AyTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.width(6.dp))
                        Switch(
                            checked = isNoticeActive,
                            onCheckedChange = { isNoticeActive = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AyGold,
                                checkedTrackColor = AyGold.copy(alpha = 0.3f),
                                uncheckedThumbColor = AyTextMuted,
                                uncheckedTrackColor = AySurfaceBorder
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = noticeTitle,
                    onValueChange = { noticeTitle = it },
                    label = { Text("নোটিশের শিরোনাম (Title)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = noticeMessage,
                    onValueChange = { noticeMessage = it },
                    label = { Text("নোটিশের বিস্তারিত বার্তা (Message)") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("INFO", "ALERT", "EVENT").forEach { typeOption ->
                        FilterChip(
                            selected = noticeType == typeOption,
                            onClick = { noticeType = typeOption },
                            label = { Text(typeOption, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AyGold,
                                selectedLabelColor = AyPitchBlack,
                                containerColor = AySurfaceCard,
                                labelColor = AyTextSecondary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        isSavingNotice = true
                        scope.launch {
                            val updatedNotice = AppNotice(
                                id = "app_notice",
                                title = noticeTitle.trim(),
                                message = noticeMessage.trim(),
                                type = noticeType,
                                isActive = isNoticeActive
                            )
                            repository.updateAppNotice(updatedNotice)
                            Toast.makeText(context, "হোম নোটিশ বোর্ড সফলভাবে আপডেট হয়েছে!", Toast.LENGTH_SHORT).show()
                            isSavingNotice = false
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
                ) {
                    if (isSavingNotice) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = AyPitchBlack)
                    } else {
                        Text("নোটিশ প্রকাশ করুন (Publish Notice)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text("পেমেন্ট ও সাপোর্ট সেটিংস", color = AyGold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text("ব্যবহারকারীরা ডিপোজিট করার সময় এবং সাপোর্টের জন্য এই তথ্যগুলো দেখতে পাবে।", color = AyTextSecondary, fontSize = 12.sp)

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
            value = waNum,
            onValueChange = { waNum = it },
            label = { Text("এডমিন হোয়াটসঅ্যাপ সাপোর্ট নম্বর (WhatsApp Number)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyEmerald, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = tgLink,
            onValueChange = { tgLink = it },
            label = { Text("অফিশিয়াল টেলিগ্রাম সাপোর্ট লিংক (Telegram Link)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyCyan, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = bkashNum,
            onValueChange = { bkashNum = it },
            label = { Text("এডমিন বিকাশ নাম্বার (Bkash Personal)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyBkashPink, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = nagadNum,
            onValueChange = { nagadNum = it },
            label = { Text("এডমিন নগদ নাম্বার (Nagad Personal)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyNagadOrange, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = rocketNum,
            onValueChange = { rocketNum = it },
            label = { Text("এডমিন রকেট নাম্বার (Rocket Personal)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyCyan, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = minDeposit,
            onValueChange = { minDeposit = it },
            label = { Text("সর্বনিম্ন ডিপোজিট লিমিট (৳) / Min Deposit") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyEmerald, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = minWithdraw,
            onValueChange = { minWithdraw = it },
            label = { Text("সর্বনিম্ন উইথড্র লিমিট (৳) / Min Withdraw") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = notice,
            onValueChange = { notice = it },
            label = { Text("ওয়ালেট ডিপোজিট নিয়মাবলী (Payment Policy Note)") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = AyGold, unfocusedBorderColor = AySurfaceBorder, focusedTextColor = AyTextPrimary, unfocusedTextColor = AyTextPrimary)
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {
                isSaving = true
                scope.launch {
                    val updated = PaymentSettings(
                        bkashNumber = bkashNum.trim(),
                        nagadNumber = nagadNum.trim(),
                        rocketNumber = rocketNum.trim(),
                        whatsappNumber = waNum.trim(),
                        telegramLink = tgLink.trim(),
                        minDeposit = minDeposit.toDoubleOrNull() ?: 20.0,
                        minWithdraw = minWithdraw.toDoubleOrNull() ?: 50.0,
                        notice = notice.trim()
                    )
                    repository.updatePaymentSettings(updated)
                    Toast.makeText(context, "সেটিংস সফলভাবে সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
                    isSaving = false
                }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
        ) {
            if (isSaving) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = AyPitchBlack)
            } else {
                Text("সেটিংস সংরক্ষণ করুন (Save Settings)", fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.height(30.dp))
    }
}
