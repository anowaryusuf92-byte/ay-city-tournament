package com.example.ui.profile

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.R
import com.example.data.repository.AppRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.firestore

class ProfileFragment : Fragment() {

    private var profileListener: ListenerRegistration? = null
    private var paymentListener: ListenerRegistration? = null
    private var activePlayerUid: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvUserName: TextView = view.findViewById(R.id.tvUserName)
        val tvUserPhone: TextView = view.findViewById(R.id.tvUserPhone)
        val tvUserUid: TextView = view.findViewById(R.id.tvUserUid)
        val btnCopyUid: Button = view.findViewById(R.id.btnCopyUid)
        val layoutUserUid: LinearLayout = view.findViewById(R.id.layoutUserUid)
        val tvDlsGamerId: TextView = view.findViewById(R.id.tvDlsGamerId)

        val tvProfileWalletBalance: TextView = view.findViewById(R.id.tvProfileWalletBalance)
        val tvProfileMinDeposit: TextView = view.findViewById(R.id.tvProfileMinDeposit)
        val tvProfileMinWithdraw: TextView = view.findViewById(R.id.tvProfileMinWithdraw)

        val btnEditDlsTeam: Button = view.findViewById(R.id.btnEditDlsTeam)
        val btnChangePassword: Button = view.findViewById(R.id.btnChangePassword)
        val btnUpdateNumber: Button = view.findViewById(R.id.btnUpdateNumber)
        val btnTelegramSupport: Button = view.findViewById(R.id.btnTelegramSupport)
        val btnWhatsAppSupport: Button = view.findViewById(R.id.btnWhatsAppSupport)
        val btnSignOut: Button = view.findViewById(R.id.btnSignOut)

        val user = Firebase.auth.currentUser
        val userId = user?.uid

        // Setup Copy UID click action
        val copyUidAction = View.OnClickListener {
            val uidToCopy = activePlayerUid.ifBlank {
                userId?.let { AppRepository.generatePlayerUid(it) } ?: "AY-10024"
            }
            val clipboard = requireContext().getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("AY CITY UID", uidToCopy)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(requireContext(), "UID Copied: $uidToCopy", Toast.LENGTH_SHORT).show()
        }
        btnCopyUid.setOnClickListener(copyUidAction)
        layoutUserUid.setOnClickListener(copyUidAction)

        if (userId != null) {
            val userEmail = user.email.orEmpty()
            val fallbackUid = AppRepository.generatePlayerUid(userId)
            activePlayerUid = fallbackUid
            tvUserUid.text = "UID: $fallbackUid"

            // Real-time listener for Player Profile
            val playerDoc = Firebase.firestore.collection("Players").document(userId)
            profileListener = playerDoc.addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener

                if (snapshot != null && snapshot.exists()) {
                    val name = snapshot.getString("name") ?: user.displayName ?: "AY CITY Player"
                    val phone = snapshot.getString("phoneNumber") ?: userEmail.ifEmpty { "+8801XXXXXXXXX" }
                    val dlsGamerId = snapshot.getString("dlsTeamName")
                    val walletBalance = snapshot.getDouble("walletBalance") ?: 5.0

                    var playerUid = snapshot.getString("playerUid")
                    if (playerUid.isNullOrBlank()) {
                        playerUid = fallbackUid
                        playerDoc.update("playerUid", playerUid)
                        Firebase.firestore.collection("users").document(userId)
                            .set(mapOf("playerUid" to playerUid), SetOptions.merge())
                    }

                    activePlayerUid = playerUid
                    tvUserName.text = name
                    tvUserPhone.text = phone
                    tvUserUid.text = "UID: $playerUid"
                    tvProfileWalletBalance.text = "Balance: ৳${"%.2f".format(walletBalance)}"

                    if (!dlsGamerId.isNullOrBlank()) {
                        tvDlsGamerId.text = "Gamer ID: $dlsGamerId"
                        tvDlsGamerId.visibility = View.VISIBLE
                    } else {
                        tvDlsGamerId.text = "Gamer ID: Not Set"
                    }
                }
            }

            // Real-time listener for Payment Limits
            paymentListener = Firebase.firestore.collection("settings").document("payments")
                .addSnapshotListener { snapshot, _ ->
                    val minDeposit = snapshot?.getDouble("minDeposit") ?: 20.0
                    val minWithdraw = snapshot?.getDouble("minWithdraw") ?: 50.0
                    tvProfileMinDeposit.text = "৳${minDeposit.toInt()}"
                    tvProfileMinWithdraw.text = "৳${minWithdraw.toInt()}"
                }

            // DLS Team / Gamer ID Dialog
            btnEditDlsTeam.setOnClickListener {
                val input = EditText(requireContext()).apply {
                    hint = "Enter DLS Team Name / Gamer ID"
                }
                AlertDialog.Builder(requireContext())
                    .setTitle("DLS Game Profile")
                    .setMessage("Set your Dream League Soccer team name or ID:")
                    .setView(input)
                    .setPositiveButton("Save") { _, _ ->
                        val value = input.text.toString().trim()
                        if (value.isNotBlank()) {
                            playerDoc.update("dlsTeamName", value)
                            Firebase.firestore.collection("users").document(userId)
                                .set(mapOf("dlsTeamName" to value), SetOptions.merge())
                            Toast.makeText(requireContext(), "DLS Gamer ID saved", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }

            // Password Reset Link
            btnChangePassword.setOnClickListener {
                if (userEmail.isNotBlank()) {
                    Firebase.auth.sendPasswordResetEmail(userEmail)
                        .addOnSuccessListener {
                            Toast.makeText(requireContext(), "Password reset link sent to $userEmail", Toast.LENGTH_LONG).show()
                        }
                        .addOnFailureListener { e ->
                            Toast.makeText(requireContext(), "Error: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                        }
                } else {
                    Toast.makeText(requireContext(), "No email associated with this account", Toast.LENGTH_SHORT).show()
                }
            }

            // Update Bkash/Nagad Phone Number
            btnUpdateNumber.setOnClickListener {
                val input = EditText(requireContext()).apply {
                    hint = "e.g., 01700000000"
                }
                AlertDialog.Builder(requireContext())
                    .setTitle("Update Phone Number")
                    .setMessage("Enter your active Bkash/Nagad number:")
                    .setView(input)
                    .setPositiveButton("Update") { _, _ ->
                        val number = input.text.toString().trim()
                        if (number.length >= 11) {
                            playerDoc.update("phoneNumber", number)
                            Firebase.firestore.collection("users").document(userId)
                                .set(mapOf("phoneNumber" to number), SetOptions.merge())
                            Toast.makeText(requireContext(), "Phone number updated", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(requireContext(), "Please enter a valid 11-digit number", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }

        // Telegram Channel Support
        btnTelegramSupport.setOnClickListener {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/aycityofficial"))
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Cannot open Telegram link", Toast.LENGTH_SHORT).show()
            }
        }

        // WhatsApp Admin Support
        btnWhatsAppSupport.setOnClickListener {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/8801900000000"))
                startActivity(intent)
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Cannot open WhatsApp link", Toast.LENGTH_SHORT).show()
            }
        }

        // Sign Out Action
        btnSignOut.setOnClickListener {
            Firebase.auth.signOut()
            Toast.makeText(requireContext(), "Signed out successfully", Toast.LENGTH_SHORT).show()
            activity?.recreate()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        profileListener?.remove()
        profileListener = null
        paymentListener?.remove()
        paymentListener = null
    }
}
