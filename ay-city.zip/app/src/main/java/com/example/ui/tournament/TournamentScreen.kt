package com.example.ui.tournament

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppNotice
import com.example.data.model.GameCategories
import com.example.data.model.Tournament
import com.example.data.model.UserProfile
import com.example.data.repository.AppRepository
import com.example.ui.theme.AyCyan
import com.example.ui.theme.AyEmerald
import com.example.ui.theme.AyGold
import com.example.ui.theme.AyPitchBlack
import com.example.ui.theme.AyRed
import com.example.ui.theme.AySurfaceBorder
import com.example.ui.theme.AySurfaceCard
import com.example.ui.theme.AySurfaceCardElevated
import com.example.ui.theme.AyTextMuted
import com.example.ui.theme.AyTextPrimary
import com.example.ui.theme.AyTextSecondary
import kotlinx.coroutines.launch

@Composable
fun TournamentScreen(
    repository: AppRepository,
    currentUser: UserProfile?,
    onNavigateToWallet: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var selectedCategory by remember { mutableStateOf("ALL") }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, UPCOMING, LIVE, COMPLETED

    val tournaments by repository.observeTournaments(
        categoryFilter = if (selectedCategory == "ALL") null else selectedCategory,
        statusFilter = if (selectedFilter == "ALL") null else selectedFilter
    ).collectAsState(initial = emptyList())

    var joiningTournament by remember { mutableStateOf<Tournament?>(null) }
    var inGameNameInput by remember { mutableStateOf("") }
    var ffUidInput by remember { mutableStateOf("") }
    var phoneInput by remember { mutableStateOf("") }
    var isJoiningLoading by remember { mutableStateOf(false) }
    var lastJoinClickTime by remember { mutableStateOf(0L) }

    val appNotice by repository.observeAppNotice().collectAsState(initial = AppNotice())

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // App Notice Banner
        if (appNotice.isActive && appNotice.message.isNotBlank()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .border(1.dp, AyGold.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = AySurfaceCardElevated),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(AyGold.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = "Notice",
                            tint = AyGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "📢 ${appNotice.title.ifBlank { "গুরুত্বপূর্ণ নোটিশ" }}",
                                color = AyGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Box(
                                modifier = Modifier
                                    .background(AyGold.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = appNotice.type,
                                    color = AyGold,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = appNotice.message,
                            color = AyTextPrimary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }
            }
        }

        // Section Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "টুর্নামেন্ট জোন",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = AyGold
                )
                Text(
                    text = "পছন্দের গেম ক্যাটাগরি বেছে নিন এবং ম্যাচে জয়েন করুন",
                    fontSize = 12.sp,
                    color = AyTextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Game Category Horizontal Cards
        val categoryItems = listOf(
            Triple("ALL", "সকল গেম", Icons.Default.SportsEsports),
            Triple(GameCategories.DLS, "DLS ফুটবল", Icons.Default.SportsSoccer),
            Triple(GameCategories.FREE_FIRE, "Free Fire", Icons.Default.Whatshot),
            Triple(GameCategories.EFOOTBALL, "eFootball", Icons.Default.SportsSoccer),
            Triple(GameCategories.CARROM, "ক্যারম পুল", Icons.Default.SportsEsports),
            Triple(GameCategories.LUDO, "লুডু কিং", Icons.Default.SportsEsports)
        )

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(categoryItems) { (code, title, icon) ->
                val isSelected = selectedCategory == code
                Card(
                    modifier = Modifier
                        .clickable { selectedCategory = code }
                        .border(
                            width = if (isSelected) 2.dp else 1.dp,
                            color = if (isSelected) AyGold else AySurfaceBorder,
                            shape = RoundedCornerShape(12.dp)
                        ),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) AyGold.copy(alpha = 0.18f) else AySurfaceCard
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(
                                    if (isSelected) AyGold else AySurfaceCardElevated,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = title,
                                tint = if (isSelected) AyPitchBlack else AyGold,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = title,
                            color = if (isSelected) AyGold else AyTextPrimary,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Status Filter Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filters = listOf(
                "ALL" to "সকল",
                "UPCOMING" to "আসন্ন",
                "LIVE" to "চলমান (Live)",
                "COMPLETED" to "সমাপ্ত"
            )
            filters.forEach { (code, label) ->
                val isSelected = selectedFilter == code
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedFilter = code },
                    label = {
                        Text(
                            text = label,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AyGold,
                        selectedLabelColor = AyPitchBlack,
                        containerColor = AySurfaceCard,
                        labelColor = AyTextSecondary
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = if (isSelected) AyGold else AySurfaceBorder
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (tournaments.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SportsEsports,
                        contentDescription = null,
                        tint = AyTextMuted,
                        modifier = Modifier.size(60.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "কোনো টুর্নামেন্ট পাওয়া যায়নি",
                        color = AyTextSecondary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "নতুন টুর্নামেন্ট খুব শীঘ্রই এড করা হবে।",
                        color = AyTextMuted,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(tournaments, key = { it.id }) { tournament ->
                    TournamentCard(
                        tournament = tournament,
                        currentUser = currentUser,
                        repository = repository,
                        onJoinClick = {
                            if (tournament.gameCategory == GameCategories.FREE_FIRE) {
                                inGameNameInput = currentUser?.ffInGameName?.ifBlank { currentUser.name } ?: ""
                                ffUidInput = currentUser?.ffUid ?: ""
                            } else {
                                inGameNameInput = currentUser?.dlsTeamName?.ifBlank { currentUser.name } ?: ""
                                ffUidInput = ""
                            }
                            phoneInput = currentUser?.phoneNumber ?: ""
                            joiningTournament = tournament
                        }
                    )
                }
            }
        }
    }

    // Join Tournament Confirmation Dialog
    if (joiningTournament != null) {
        val tour = joiningTournament!!
        val isFree = tour.entryFee <= 0.0
        val userBalance = currentUser?.walletBalance ?: 0.0
        val hasEnoughBalance = isFree || (userBalance >= tour.entryFee)
        val isFreeFire = tour.gameCategory == GameCategories.FREE_FIRE

        AlertDialog(
            onDismissRequest = { if (!isJoiningLoading) joiningTournament = null },
            containerColor = AySurfaceCard,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isFreeFire) Icons.Default.Whatshot else Icons.Default.SportsSoccer,
                        contentDescription = null,
                        tint = AyGold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "টুর্নামেন্টে জয়েন করুন", color = AyGold, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(
                        text = tour.title,
                        fontWeight = FontWeight.Bold,
                        color = AyTextPrimary,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "ক্যাটাগরি: ${tour.gameCategory} | মোড: ${tour.matchType}",
                        color = AyTextSecondary,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AySurfaceCardElevated, RoundedCornerShape(8.dp))
                            .padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("এন্ট্রি ফি", color = AyTextMuted, fontSize = 11.sp)
                            Text(
                                if (isFree) "ফ্রি (৳০)" else "৳${tour.entryFee}",
                                color = if (isFree) AyEmerald else AyGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("আপনার ওয়ালেট", color = AyTextMuted, fontSize = 11.sp)
                            Text(
                                "৳${"%.2f".format(userBalance)}",
                                color = if (hasEnoughBalance) AyEmerald else AyRed,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (!hasEnoughBalance) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = AyRed.copy(alpha = 0.15f)),
                            border = BorderStroke(1.dp, AyRed),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = AyRed)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "আপনার পর্যাপ্ত ব্যালেন্স নেই! জয়েন করতে ওয়ালেটে টাকা এড করুন।",
                                    color = AyRed,
                                    fontSize = 12.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    // In-Game Name / Team Name input
                    OutlinedTextField(
                        value = inGameNameInput,
                        onValueChange = { inGameNameInput = it },
                        label = {
                            Text(if (isFreeFire) "ফ্রি ফায়ার In-Game Name (IGN)" else "টিম বা প্লেয়ার নেম (Team Name)")
                        },
                        placeholder = { Text("গেমের সঠিক নাম লিখুন", color = AyTextMuted) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AyGold,
                            unfocusedBorderColor = AySurfaceBorder,
                            focusedTextColor = AyTextPrimary,
                            unfocusedTextColor = AyTextPrimary
                        )
                    )

                    // FF UID input specifically for Free Fire matches
                    if (isFreeFire) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = ffUidInput,
                            onValueChange = { ffUidInput = it },
                            label = { Text("Free Fire UID (FF UID)") },
                            placeholder = { Text("যেমন: 1234567890", color = AyTextMuted) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AyGold,
                                unfocusedBorderColor = AySurfaceBorder,
                                focusedTextColor = AyTextPrimary,
                                unfocusedTextColor = AyTextPrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Contact Phone
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("মোবাইল নম্বর (যোগাযোগের জন্য)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AyGold,
                            unfocusedBorderColor = AySurfaceBorder,
                            focusedTextColor = AyTextPrimary,
                            unfocusedTextColor = AyTextPrimary
                        )
                    )
                }
            },
            confirmButton = {
                if (hasEnoughBalance) {
                    Button(
                        onClick = {
                            if (android.os.SystemClock.elapsedRealtime() - lastJoinClickTime < 1500) {
                                return@Button
                            }
                            lastJoinClickTime = android.os.SystemClock.elapsedRealtime()

                            if (inGameNameInput.isBlank()) {
                                Toast.makeText(
                                    context,
                                    if (isFreeFire) "Free Fire In-Game Name লিখুন" else "টিমের নাম লিখুন",
                                    Toast.LENGTH_SHORT
                                ).show()
                                return@Button
                            }
                            if (isFreeFire && ffUidInput.isBlank()) {
                                Toast.makeText(context, "Free Fire UID প্রদান করুন", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            isJoiningLoading = true
                            scope.launch {
                                currentUser?.let { user ->
                                    val result = repository.joinTournament(
                                        tournament = tour,
                                        user = user,
                                        dlsTeamName = inGameNameInput.trim(),
                                        phone = phoneInput.trim(),
                                        gameUid = ffUidInput.trim()
                                    )
                                    if (result.isSuccess) {
                                        Toast.makeText(context, "সফলভাবে জয়েন সম্পন্ন হয়েছে!", Toast.LENGTH_LONG).show()
                                        com.example.util.NotificationHelper.showNotification(
                                            context,
                                            "ম্যাচ জয়েনিং কনফার্মেশন",
                                            "${tour.title} এ সফলভাবে জয়েন সম্পন্ন হয়েছে!"
                                        )
                                        joiningTournament = null
                                    } else {
                                        Toast.makeText(
                                            context,
                                            result.exceptionOrNull()?.message ?: "জয়েন ব্যর্থ হয়েছে",
                                            Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                                isJoiningLoading = false
                            }
                        },
                        enabled = !isJoiningLoading,
                        colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
                    ) {
                        if (isJoiningLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = AyPitchBlack)
                        } else {
                            Text(
                                if (isFree) "ফ্রি জয়েন করুন (Free Entry)" else "কনফার্ম জয়েন (৳${tour.entryFee})",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    Button(
                        onClick = {
                            joiningTournament = null
                            onNavigateToWallet()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AyEmerald, contentColor = Color.White)
                    ) {
                        Text("ওয়ালেটে টাকা এড করুন", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { joiningTournament = null },
                    enabled = !isJoiningLoading
                ) {
                    Text("বাতিল", color = AyTextMuted)
                }
            }
        )
    }
}

@Composable
fun TournamentCard(
    tournament: Tournament,
    currentUser: UserProfile?,
    repository: AppRepository,
    onJoinClick: () -> Unit
) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    val currentUserId = currentUser?.id ?: ""

    // Check if user is joined
    val isJoined by repository.isUserJoined(tournament.id, currentUserId)
        .collectAsState(initial = false)

    val is1v1 = tournament.matchType.contains("1v1", ignoreCase = true) || tournament.maxSlots == 2
    val effectiveMaxSlots = if (is1v1) 2 else tournament.maxSlots
    val isFull = tournament.joinedCount >= effectiveMaxSlots
    val participants by repository.observeParticipants(tournament.id).collectAsState(initial = emptyList())

    var showRules by remember { mutableStateOf(false) }
    var showRoomDetailsDialog by remember { mutableStateOf(false) }

    val statusColor = when (tournament.status) {
        "LIVE" -> AyEmerald
        "COMPLETED" -> AyTextMuted
        "CANCELLED" -> AyRed
        else -> AyGold
    }

    val statusLabel = when (tournament.status) {
        "LIVE" -> "চলমান (LIVE)"
        "COMPLETED" -> "সমাপ্ত"
        "CANCELLED" -> "বাতিল"
        else -> "আসন্ন (UPCOMING)"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isJoined) AyEmerald.copy(alpha = 0.6f) else AySurfaceBorder,
                RoundedCornerShape(16.dp)
            ),
        colors = CardDefaults.cardColors(containerColor = AySurfaceCard),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Category Badge + Mode + Status Chip
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(AyGold.copy(alpha = 0.15f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = tournament.gameCategory,
                            color = AyGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${tournament.matchType}",
                        color = AyTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (tournament.mapType.isNotBlank() && tournament.mapType != "Default") {
                        Text(
                            text = " (${tournament.mapType})",
                            color = AyTextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                // Status Chip
                Box(
                    modifier = Modifier
                        .background(statusColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = statusLabel,
                        color = statusColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Title
            Text(
                text = tournament.title,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = AyTextPrimary
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Match Time
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AccessTime,
                    contentDescription = null,
                    tint = AyCyan,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = tournament.matchTime.ifBlank { "আজকে ম্যাচ অনুষ্ঠিত হবে" },
                    color = AyTextSecondary,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Key Metrics Grid
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AySurfaceCardElevated, RoundedCornerShape(12.dp))
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("১ম পুরস্কার", color = AyTextMuted, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = AyGold, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("৳${tournament.prizePool}", color = AyGold, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }

                Column {
                    Text("এন্ট্রি ফি", color = AyTextMuted, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Payments, contentDescription = null, tint = AyEmerald, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            if (tournament.entryFee == 0.0) "ফ্রি" else "৳${tournament.entryFee}",
                            color = AyEmerald,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("স্লট লিমিট", color = AyTextMuted, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Groups, contentDescription = null, tint = AyCyan, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("${tournament.joinedCount}/$effectiveMaxSlots", color = AyCyan, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Slots Progress Bar
            val progress = (tournament.joinedCount.toFloat() / effectiveMaxSlots.toFloat()).coerceIn(0f, 1f)
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (isFull) AyRed else AyEmerald,
                trackColor = AySurfaceBorder
            )

            // 1v1 VS Matchup Section (Classic 1v1 View)
            if (is1v1) {
                Spacer(modifier = Modifier.height(12.dp))
                val p1 = participants.getOrNull(0)
                val p2 = participants.getOrNull(1)
                val p1Name = p1?.inGameName?.takeIf { it.isNotBlank() }
                    ?: p1?.dlsTeamName?.takeIf { it.isNotBlank() }
                    ?: p1?.userName?.takeIf { it.isNotBlank() }
                    ?: "Player 1 (অপেক্ষমান)"
                val p2Name = p2?.inGameName?.takeIf { it.isNotBlank() }
                    ?: p2?.dlsTeamName?.takeIf { it.isNotBlank() }
                    ?: p2?.userName?.takeIf { it.isNotBlank() }
                    ?: "Slot 2 (খালি)"

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AyPitchBlack.copy(alpha = 0.55f)),
                    border = BorderStroke(1.dp, AyGold.copy(alpha = 0.35f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Player 1
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(if (p1 != null) AyEmerald.copy(alpha = 0.2f) else AySurfaceBorder, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "P1",
                                    color = if (p1 != null) AyEmerald else AyTextMuted,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = p1Name,
                                    color = if (p1 != null) AyTextPrimary else AyTextMuted,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = if (p1 != null) "টিম ১" else "স্লট ১",
                                    color = AyTextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        // VS Badge
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 8.dp)
                                .background(
                                    brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                                        listOf(AyRed, AyGold)
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = "VS",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp
                            )
                        }

                        // Player 2
                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = p2Name,
                                    color = if (p2 != null) AyTextPrimary else AyTextMuted,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = if (p2 != null) "টিম ২" else "স্লট ২ (খালি)",
                                    color = if (p2 != null) AyTextMuted else AyGold,
                                    fontSize = 10.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(if (p2 != null) AyCyan.copy(alpha = 0.2f) else AySurfaceBorder, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "P2",
                                    color = if (p2 != null) AyCyan else AyTextMuted,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Room ID & Password Security Section
            if (isJoined) {
                // User is successfully joined -> Reveal Room Details
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AyEmerald.copy(alpha = 0.12f)),
                    border = BorderStroke(1.dp, AyEmerald),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.MeetingRoom, contentDescription = null, tint = AyEmerald, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${tournament.gameCategory} রুম আইডি ও পাসওয়ার্ড",
                                    color = AyEmerald,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                            Text(
                                text = "অংশগ্রহণ করেছেন ✓",
                                color = AyEmerald,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        if (tournament.roomCode.isNotBlank()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(AySurfaceCard, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "রুম কোড: ${tournament.roomCode}",
                                        color = AyGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    if (tournament.roomPassword.isNotBlank()) {
                                        Text(
                                            text = "পাসওয়ার্ড: ${tournament.roomPassword}",
                                            color = AyTextPrimary,
                                            fontSize = 12.sp
                                        )
                                    }
                                }

                                Row {
                                    IconButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(tournament.roomCode))
                                            Toast.makeText(context, "রুম কোড কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = AyGold)
                                    }
                                    IconButton(
                                        onClick = { showRoomDetailsDialog = true }
                                    ) {
                                        Icon(Icons.Default.Key, contentDescription = "Popup", tint = AyEmerald)
                                    }
                                }
                            }
                        } else {
                            Text(
                                text = "ম্যাচ শুরুর ১০-১৫ মিনিট পূর্বে রুম কোড দেওয়া হবে। পেজটি রিফ্রেশ রাখুন।",
                                color = AyTextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            } else {
                // Not joined -> Locked Room ID & Password Security
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AySurfaceCardElevated.copy(alpha = 0.5f)),
                    border = BorderStroke(1.dp, AySurfaceBorder),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(AySurfaceBorder, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = "Locked", tint = AyGold, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "রুম আইডি ও পাসওয়ার্ড লক করা রয়েছে",
                                color = AyTextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                            Text(
                                text = "শুধুমাত্র জয়েনকৃত প্লেয়ারদের জন্য ম্যাচ শুরুর পূর্বে এটি উন্মুক্ত হবে।",
                                color = AyTextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Permanent Match Instructions & Rules Section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showRules = !showRules },
                colors = CardDefaults.cardColors(containerColor = AySurfaceCardElevated),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = AyGold, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ম্যাচ রুলস ও নির্দেশিকা (Match Rules)",
                                color = AyGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                        Icon(
                            imageVector = if (showRules) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = "Toggle Rules",
                            tint = AyTextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    AnimatedVisibility(visible = showRules) {
                        Column(modifier = Modifier.padding(top = 8.dp)) {
                            Text(
                                text = GameCategories.getDefaultRules(tournament.gameCategory),
                                color = AyTextSecondary,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                            if (tournament.rules.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "বিশেষ রুলস:\n${tournament.rules}",
                                    color = AyCyan,
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                }
            }

            // Winner display if completed
            if (tournament.status == "COMPLETED" && tournament.winnerName.isNotBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(AyGold.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = AyGold, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "চ্যাম্পিয়ন: ${tournament.winnerName} (৳${tournament.prizePool} বিজয়ী)",
                        color = AyGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Button
            if (tournament.status == "COMPLETED" || tournament.status == "CANCELLED") {
                Button(
                    onClick = {},
                    enabled = false,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        disabledContainerColor = AySurfaceBorder,
                        disabledContentColor = AyTextMuted
                    )
                ) {
                    Text(if (tournament.status == "COMPLETED") "টুর্নামেন্ট সমাপ্ত" else "টুর্নামেন্ট বাতিল")
                }
            } else if (isJoined) {
                OutlinedButton(
                    onClick = { showRoomDetailsDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AyEmerald),
                    border = BorderStroke(1.dp, AyEmerald)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AyEmerald, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("আপনি জয়েন করেছেন • রুম তথ্য দেখুন", fontWeight = FontWeight.Bold)
                }
            } else if (isFull) {
                Button(
                    onClick = {},
                    enabled = false,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        disabledContainerColor = AySurfaceBorder,
                        disabledContentColor = AyTextMuted
                    )
                ) {
                    Text("স্লট পূর্ণ (Full)")
                }
            } else {
                Button(
                    onClick = onJoinClick,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AyGold,
                        contentColor = AyPitchBlack
                    )
                ) {
                    Text(
                        text = if (tournament.entryFee == 0.0) "জয়েন করুন (ফ্রি ৳০)" else "জয়েন করুন (৳${tournament.entryFee})",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }

    // Room Details Popup Dialog (Only Accessible to Joined Users)
    if (showRoomDetailsDialog && isJoined) {
        AlertDialog(
            onDismissRequest = { showRoomDetailsDialog = false },
            containerColor = AySurfaceCard,
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Key, contentDescription = null, tint = AyGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("রুম ক্রেডেনশিয়াল ও তথ্য", color = AyGold, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column {
                    Text(tournament.title, color = AyTextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    if (tournament.roomCode.isNotBlank()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = AyPitchBlack),
                            border = BorderStroke(1.dp, AyGold),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("রুম আইডি / কোড:", color = AyTextMuted, fontSize = 11.sp)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        tournament.roomCode,
                                        color = AyGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                    IconButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(tournament.roomCode))
                                            Toast.makeText(context, "রুম কোড কপি হয়েছে!", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = AyGold)
                                    }
                                }

                                if (tournament.roomPassword.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("পাসওয়ার্ড:", color = AyTextMuted, fontSize = 11.sp)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            tournament.roomPassword,
                                            color = AyCyan,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp
                                        )
                                        IconButton(
                                            onClick = {
                                                clipboardManager.setText(AnnotatedString(tournament.roomPassword))
                                                Toast.makeText(context, "পাসওয়ার্ড কপি হয়েছে!", Toast.LENGTH_SHORT).show()
                                            }
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = AyCyan)
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "ম্যাচ শুরুর ১০-১৫ মিনিট আগে রুম আইডি ও পাসওয়ার্ড এই বক্সে আপডেট হবে। দয়া করে প্রস্তুত থাকুন।",
                            color = AyTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showRoomDetailsDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
                ) {
                    Text("ঠিক আছে", fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
