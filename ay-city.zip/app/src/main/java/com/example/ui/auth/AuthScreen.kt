package com.example.ui.auth

import android.app.Activity
import android.util.Log
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.repository.AppRepository
import com.example.ui.theme.AyDarkBackground
import com.example.ui.theme.AyEmerald
import com.example.ui.theme.AyGold
import com.example.ui.theme.AyPitchBlack
import com.example.ui.theme.AyRed
import com.example.ui.theme.AySurfaceBorder
import com.example.ui.theme.AySurfaceCard
import com.example.ui.theme.AyTextMuted
import com.example.ui.theme.AyTextPrimary
import com.example.ui.theme.AyTextSecondary
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@Composable
fun AuthScreen(
    repository: AppRepository,
    onAuthSuccess: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Login, 1: Register

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var dlsTeamName by remember { mutableStateOf("") }
    var referralCodeInput by remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }

    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var successMessage by remember { mutableStateOf<String?>(null) }

    val credentialManager = remember { CredentialManager.create(context) }

    fun handleGoogleSignIn() {
        val clientId = try {
            context.getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            errorMessage = "Google Web Client ID missing!"
            return
        }

        isLoading = true
        errorMessage = null
        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

        scope.launch {
            try {
                val result = credentialManager.getCredential(context as Activity, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    val authResult = Firebase.auth.signInWithCredential(authCredential).await()
                    val user = authResult.user
                    if (user != null) {
                        repository.ensureUserProfile(
                            uid = user.uid,
                            email = user.email ?: "",
                            displayName = user.displayName,
                            photoUrl = user.photoUrl?.toString()
                        )
                        onAuthSuccess()
                    }
                } else {
                    errorMessage = "Unexpected Google credential."
                }
            } catch (e: GetCredentialCancellationException) {
                Log.w("Auth", "Google sign in cancelled: ${e.message}")
            } catch (e: Exception) {
                Log.e("Auth", "Google sign in failed", e)
                errorMessage = e.localizedMessage ?: "Google sign in failed"
            } finally {
                isLoading = false
            }
        }
    }

    fun handleEmailAuth() {
        if (email.isBlank() || password.isBlank()) {
            errorMessage = "ইমেইল ও পাসওয়ার্ড প্রদান করুন"
            return
        }
        if (password.length < 6) {
            errorMessage = "পাসওয়ার্ড অন্তত ৬ অক্ষরের হতে হবে"
            return
        }

        isLoading = true
        errorMessage = null
        successMessage = null

        scope.launch {
            try {
                if (selectedTab == 0) {
                    // Login
                    val result = Firebase.auth.signInWithEmailAndPassword(email.trim(), password).await()
                    val user = result.user
                    if (user != null) {
                        repository.ensureUserProfile(
                            uid = user.uid,
                            email = user.email ?: email.trim(),
                            displayName = user.displayName,
                            photoUrl = user.photoUrl?.toString()
                        )
                        onAuthSuccess()
                    }
                } else {
                    // Register
                    val result = Firebase.auth.createUserWithEmailAndPassword(email.trim(), password).await()
                    val user = result.user
                    if (user != null) {
                        val profile = repository.ensureUserProfile(
                            uid = user.uid,
                            email = email.trim(),
                            displayName = name.trim().ifBlank { null },
                            photoUrl = null,
                            referralCodeInput = referralCodeInput.trim().ifBlank { null }
                        )
                        if (phone.isNotBlank() || dlsTeamName.isNotBlank()) {
                            repository.updateUserProfile(
                                uid = user.uid,
                                name = name.trim().ifBlank { profile.name },
                                phone = phone.trim(),
                                dlsTeamName = dlsTeamName.trim()
                            )
                        }
                        onAuthSuccess()
                    }
                }
            } catch (e: Exception) {
                Log.e("Auth", "Email auth failed", e)
                errorMessage = e.localizedMessage ?: "অথেন্টিকেশন ব্যর্থ হয়েছে"
            } finally {
                isLoading = false
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        AyPitchBlack,
                        AyDarkBackground,
                        Color(0xFF060913)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // App Branding Crest Logo
            Box(
                modifier = Modifier
                    .size(110.dp)
                    .clip(CircleShape)
                    .border(2.dp, AyGold, CircleShape)
                    .background(AySurfaceCard),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ay_city_logo),
                    contentDescription = "AY CITY Logo",
                    modifier = Modifier.size(100.dp).clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "AY CITY",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                color = AyGold,
                letterSpacing = 2.sp
            )

            Text(
                text = "DLS Football Tournament Management",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = AyTextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Bonus Highlight Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AyGold.copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(
                    containerColor = AyEmerald.copy(alpha = 0.15f)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Bonus",
                        tint = AyGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "নতুন একাউন্ট করলেই ফ্রি ৳৫ সাইন-আপ বোনাস!",
                        color = AyGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Auth Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AySurfaceBorder, RoundedCornerShape(20.dp)),
                colors = CardDefaults.cardColors(containerColor = AySurfaceCard),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    // Tabs
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = AySurfaceCard,
                        contentColor = AyGold,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = AyGold
                            )
                        }
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = {
                                selectedTab = 0
                                errorMessage = null
                            },
                            text = {
                                Text(
                                    "লগইন (Login)",
                                    fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == 0) AyGold else AyTextMuted
                                )
                            }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = {
                                selectedTab = 1
                                errorMessage = null
                            },
                            text = {
                                Text(
                                    "রেজিস্টার (Register)",
                                    fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedTab == 1) AyGold else AyTextMuted
                                )
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Registration specific fields
                    AnimatedVisibility(visible = selectedTab == 1) {
                        Column {
                            OutlinedTextField(
                                value = name,
                                onValueChange = { name = it },
                                label = { Text("আপনার নাম (Player Name)") },
                                leadingIcon = {
                                    Icon(Icons.Default.Person, contentDescription = null, tint = AyGold)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AyGold,
                                    unfocusedBorderColor = AySurfaceBorder,
                                    focusedTextColor = AyTextPrimary,
                                    unfocusedTextColor = AyTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = phone,
                                onValueChange = { phone = it },
                                label = { Text("মোবাইল নম্বর (Phone)") },
                                leadingIcon = {
                                    Icon(Icons.Default.Phone, contentDescription = null, tint = AyGold)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AyGold,
                                    unfocusedBorderColor = AySurfaceBorder,
                                    focusedTextColor = AyTextPrimary,
                                    unfocusedTextColor = AyTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = dlsTeamName,
                                onValueChange = { dlsTeamName = it },
                                label = { Text("গেমার / টিম নাম (In-game Name)") },
                                leadingIcon = {
                                    Icon(Icons.Default.SportsSoccer, contentDescription = null, tint = AyGold)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AyGold,
                                    unfocusedBorderColor = AySurfaceBorder,
                                    focusedTextColor = AyTextPrimary,
                                    unfocusedTextColor = AyTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = referralCodeInput,
                                onValueChange = { referralCodeInput = it.uppercase() },
                                label = { Text("রেফার কোড (ঐচ্ছিক / Optional)") },
                                placeholder = { Text("যেমন: AY-12345", color = AyTextSecondary) },
                                leadingIcon = {
                                    Icon(Icons.Default.Star, contentDescription = null, tint = AyGold)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = AyGold,
                                    unfocusedBorderColor = AySurfaceBorder,
                                    focusedTextColor = AyTextPrimary,
                                    unfocusedTextColor = AyTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                    }

                    // Email Field
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("ইমেইল এড্রেস (Email)") },
                        leadingIcon = {
                            Icon(Icons.Default.Email, contentDescription = null, tint = AyGold)
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AyGold,
                            unfocusedBorderColor = AySurfaceBorder,
                            focusedTextColor = AyTextPrimary,
                            unfocusedTextColor = AyTextPrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Password Field
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("পাসওয়ার্ড (Password)") },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = AyGold)
                        },
                        trailingIcon = {
                            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                                Icon(
                                    imageVector = if (isPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = "Toggle password",
                                    tint = AyTextSecondary
                                )
                            }
                        },
                        visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AyGold,
                            unfocusedBorderColor = AySurfaceBorder,
                            focusedTextColor = AyTextPrimary,
                            unfocusedTextColor = AyTextPrimary
                        )
                    )

                    // Error text
                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorMessage ?: "",
                            color = AyRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Primary Submit Button
                    Button(
                        onClick = { handleEmailAuth() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        enabled = !isLoading,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AyGold,
                            contentColor = AyPitchBlack
                        )
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = AyPitchBlack,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = if (selectedTab == 0) "লগইন করুন" else "রেজিস্টার করুন (বোনাস নিন)",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = AySurfaceBorder
                        )
                        Text(
                            text = " অথবা ",
                            color = AyTextMuted,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = AySurfaceBorder
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Google Sign In Button
                    OutlinedButton(
                        onClick = { handleGoogleSignIn() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        enabled = !isLoading,
                        shape = RoundedCornerShape(12.dp),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = Brush.horizontalGradient(listOf(AyGold, AyEmerald))
                        ),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = Color.Transparent
                        )
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SportsSoccer,
                                contentDescription = null,
                                tint = AyGold,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "গুগল দিয়ে সাইন ইন (Sign in with Google)",
                                color = AyTextPrimary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "AY CITY DLS Tournament Platform • All Rights Reserved",
                fontSize = 11.sp,
                color = AyTextMuted,
                textAlign = TextAlign.Center
            )
        }
    }
}
