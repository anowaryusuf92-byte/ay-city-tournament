package com.example.ui.profile

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import coil.compose.AsyncImage
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import com.example.R
import com.example.data.model.ADMIN_UID
import com.example.data.model.PaymentSettings
import com.example.data.model.UserProfile
import com.example.data.repository.AppRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

private val DarkSlateBg = Color(0xFF0F172A)
private val CardSlateBg = Color(0xFF1E293B)
private val DividerSlate = Color(0xFF334155)
private val TextMutedSlate = Color(0xFF94A3B8)
private val TextLightSlate = Color(0xFFE2E8F0)
private val AmberGold = Color(0xFFF59E0B)
private val TelegramBlue = Color(0xFF38BDF8)
private val WhatsAppGreen = Color(0xFF22C55E)
private val RedSignOut = Color(0xFFEF4444)

@Composable
fun ProfileScreen(
    repository: AppRepository,
    currentUser: UserProfile?,
    onNavigateToAdmin: () -> Unit,
    onSignOut: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current
    val credentialManager = remember { CredentialManager.create(context) }

    val activeUid = (currentUser?.id ?: repository.getCurrentUserId()) ?: ""
    val liveProfile by repository.observeUserProfile(activeUid).collectAsState(initial = currentUser)
    val currentBalance = liveProfile?.walletBalance ?: (currentUser?.walletBalance ?: 5.0)
    val paymentSettings by repository.observePaymentSettings().collectAsState(initial = PaymentSettings())
    val playerShortUid = liveProfile?.playerUid?.takeIf { it.isNotBlank() }
        ?: (currentUser?.playerUid?.takeIf { it.isNotBlank() }
        ?: AppRepository.generatePlayerUid(activeUid))

    val isAdmin = currentUser?.role == "admin" || currentUser?.id == ADMIN_UID

    // Modal dialog control states
    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showDlsDialog by remember { mutableStateOf(false) }
    var showPasswordDialog by remember { mutableStateOf(false) }
    var showPhoneDialog by remember { mutableStateOf(false) }
    var showTelegramDialog by remember { mutableStateOf(false) }
    var showWhatsAppDialog by remember { mutableStateOf(false) }

    // Input fields state
    var dlsTeamInput by remember { mutableStateOf(currentUser?.dlsTeamName ?: "") }
    var ffNameInput by remember { mutableStateOf(currentUser?.ffInGameName ?: "") }
    var ffUidInput by remember { mutableStateOf(currentUser?.ffUid ?: "") }
    var phoneInput by remember { mutableStateOf(currentUser?.phoneNumber ?: "") }
    var editNameInput by remember { mutableStateOf(currentUser?.name ?: "") }
    var editPhotoUrlInput by remember { mutableStateOf(currentUser?.photoUrl ?: "") }
    var isSaving by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkSlateBg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // User Profile Header Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardSlateBg),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Clickable Avatar with edit icon badge
                val currentPhoto = liveProfile?.photoUrl?.takeIf { it.isNotBlank() } ?: (currentUser?.photoUrl ?: "")
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .clip(CircleShape)
                        .background(AmberGold.copy(alpha = 0.15f))
                        .border(2.dp, AmberGold, CircleShape)
                        .clickable {
                            editNameInput = liveProfile?.name ?: currentUser?.name ?: ""
                            phoneInput = liveProfile?.phoneNumber ?: currentUser?.phoneNumber ?: ""
                            dlsTeamInput = liveProfile?.dlsTeamName ?: currentUser?.dlsTeamName ?: ""
                            ffNameInput = liveProfile?.ffInGameName ?: currentUser?.ffInGameName ?: ""
                            ffUidInput = liveProfile?.ffUid ?: currentUser?.ffUid ?: ""
                            editPhotoUrlInput = currentPhoto
                            showEditProfileDialog = true
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (currentPhoto.isNotBlank()) {
                        AsyncImage(
                            model = currentPhoto,
                            contentDescription = "Profile Avatar",
                            modifier = Modifier.fillMaxSize().clip(CircleShape),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                        )
                    } else {
                        Image(
                            painter = painterResource(id = R.drawable.ic_player_avatar),
                            contentDescription = "Profile Avatar",
                            modifier = Modifier.size(56.dp)
                        )
                    }

                    // Edit camera badge
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(24.dp)
                            .background(AmberGold, CircleShape)
                            .border(1.dp, CardSlateBg, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.PhotoCamera,
                            contentDescription = "Edit Picture",
                            tint = Color.Black,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = liveProfile?.name?.takeIf { it.isNotBlank() } ?: (currentUser?.name?.takeIf { it.isNotBlank() } ?: "AY CITY Player"),
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = liveProfile?.phoneNumber?.takeIf { it.isNotBlank() }
                        ?: (currentUser?.phoneNumber?.takeIf { it.isNotBlank() }
                        ?: (currentUser?.email?.takeIf { it.isNotBlank() } ?: "+8801XXXXXXXXX")),
                    color = TextMutedSlate,
                    fontSize = 14.sp
                )


                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF334155))
                        .padding(start = 12.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "UID: $playerShortUid",
                        color = TextLightSlate,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(playerShortUid))
                            Toast.makeText(context, "UID Copied: $playerShortUid", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = TelegramBlue),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text(
                            text = "📋 Copy UID",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                val gamerId = liveProfile?.dlsTeamName?.takeIf { it.isNotBlank() }
                    ?: (currentUser?.dlsTeamName?.takeIf { it.isNotBlank() })
                if (!gamerId.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "DLS Team: $gamerId",
                        color = AmberGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                val ffIgn = liveProfile?.ffInGameName?.takeIf { it.isNotBlank() } ?: (currentUser?.ffInGameName?.takeIf { it.isNotBlank() })
                val ffId = liveProfile?.ffUid?.takeIf { it.isNotBlank() } ?: (currentUser?.ffUid?.takeIf { it.isNotBlank() })
                if (!ffIgn.isNullOrBlank() || !ffId.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Free Fire: ${ffIgn ?: ""} (UID: ${ffId ?: ""})",
                        color = WhatsAppGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        editNameInput = liveProfile?.name ?: currentUser?.name ?: ""
                        phoneInput = liveProfile?.phoneNumber ?: currentUser?.phoneNumber ?: ""
                        dlsTeamInput = liveProfile?.dlsTeamName ?: currentUser?.dlsTeamName ?: ""
                        ffNameInput = liveProfile?.ffInGameName ?: currentUser?.ffInGameName ?: ""
                        ffUidInput = liveProfile?.ffUid ?: currentUser?.ffUid ?: ""
                        editPhotoUrlInput = currentPhoto
                        showEditProfileDialog = true
                    },
                    shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AmberGold),
                    border = ButtonDefaults.outlinedButtonBorder.copy(
                        brush = androidx.compose.ui.graphics.SolidColor(AmberGold)
                    ),
                    modifier = Modifier.height(34.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                ) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text("প্রোফাইল ও ছবি এডিট করুন (Edit Profile)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                if (isAdmin) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .background(AmberGold.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 10.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "⚡ ADMIN ACCOUNT",
                            color = AmberGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Refer & Earn Banner Card
        Spacer(modifier = Modifier.height(14.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardSlateBg),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, AmberGold.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = AmberGold, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "🎁 রেফার করুন ও ৳১০ বোনাস জিতে নিন (Refer & Earn)",
                        color = AmberGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "আপনার বন্ধুদের রেফার কোডটি শেয়ার করুন। আপনার কোড দিয়ে একাউন্ট খুলে ডিপোজিট বা টুর্নামেন্টে জয়েন করলেই আপনি পাবেন ইনস্ট্যান্ট ৳১০ বোনাস!",
                    color = TextLightSlate,
                    fontSize = 11.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                        .border(1.dp, DividerSlate, RoundedCornerShape(10.dp))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("আপনার রেফারেল কোড", color = TextMutedSlate, fontSize = 10.sp)
                        Text(
                            text = playerShortUid,
                            color = AmberGold,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                    }
                    Row {
                        Button(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(playerShortUid))
                                Toast.makeText(context, "রেফার কোড কপি হয়েছে: $playerShortUid", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = Color.Black),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("কপি", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        OutlinedButton(
                            onClick = {
                                val shareText = "🔥 DLS TOURNAMENT এ যুক্ত হন এবং টুর্নামেন্ট খেলে টাকা জিতুন! সাইন-আপ করার সময় আমার রেফার কোডটি ব্যবহার করুন: $playerShortUid"
                                val intent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, shareText)
                                }
                                context.startActivity(Intent.createChooser(intent, "রেফার কোড শেয়ার করুন"))
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = TelegramBlue),
                            border = BorderStroke(1.dp, TelegramBlue),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("শেয়ার", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Wallet Limits & Controls Card
        Spacer(modifier = Modifier.height(16.dp))
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardSlateBg),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "💳 Wallet & Limit Controls",
                        color = TextLightSlate,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Balance: ৳${"%.2f".format(currentBalance)}",
                        color = AmberGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Min Deposit info box
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                            .border(1.dp, WhatsAppGreen.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("Min Deposit", color = TextMutedSlate, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("৳${paymentSettings.minDeposit.toInt()}", color = WhatsAppGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }

                    // Min Withdraw info box
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                            .border(1.dp, AmberGold.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("Min Withdraw", color = TextMutedSlate, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("৳${paymentSettings.minWithdraw.toInt()}", color = AmberGold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }

                    // Bonus info box
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(Color(0xFF0F172A), RoundedCornerShape(10.dp))
                            .border(1.dp, TelegramBlue.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text("Bonus", color = TextMutedSlate, fontSize = 11.sp)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("৳5.00", color = TelegramBlue, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    }
                }
            }
        }

        // DLS Game Profile Section
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "🎮 DLS Game Profile",
            color = TextLightSlate,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardSlateBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            dlsTeamInput = currentUser?.dlsTeamName ?: ""
                            showDlsDialog = true
                        }
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("⚽", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Set DLS Team Name & Gamer ID",
                                color = AmberGold,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = if (!currentUser?.dlsTeamName.isNullOrBlank()) {
                                    "Current: ${currentUser?.dlsTeamName}"
                                } else {
                                    "Not configured yet"
                                },
                                color = TextMutedSlate,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Open",
                        tint = AmberGold
                    )
                }
            }
        }

        // Account Security & Controls Section
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "🔒 Account Security & Controls",
            color = TextLightSlate,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardSlateBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Password Reset Link
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showPasswordDialog = true }
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("🔑", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Send Password Reset Link",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Receive reset instructions via email",
                                color = TextMutedSlate,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Open",
                        tint = TextMutedSlate
                    )
                }

                HorizontalDivider(color = DividerSlate, thickness = 1.dp)

                // Update Phone Number
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            phoneInput = currentUser?.phoneNumber ?: ""
                            showPhoneDialog = true
                        }
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("📱", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Update Bkash/Nagad Phone Number",
                                color = Color.White,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = if (!currentUser?.phoneNumber.isNullOrBlank()) {
                                    "Linked: ${currentUser?.phoneNumber}"
                                } else {
                                    "No phone number linked"
                                },
                                color = TextMutedSlate,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Open",
                        tint = TextMutedSlate
                    )
                }
            }
        }

        // Support & Help Desk Section
        Spacer(modifier = Modifier.height(20.dp))
        Text(
            text = "💬 Support & Help Desk",
            color = TextLightSlate,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = CardSlateBg),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Official Telegram Channel
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable {
                            launchTelegramSupport(context, paymentSettings.telegramLink)
                        }
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("✈️", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Official Telegram Support Channel",
                                color = TelegramBlue,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Tournaments, updates & live notices",
                                color = TextMutedSlate,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Open",
                        tint = TelegramBlue
                    )
                }

                HorizontalDivider(color = DividerSlate, thickness = 1.dp)

                // Direct WhatsApp Admin Support
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showWhatsAppDialog = true }
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("🟢", fontSize = 18.sp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Admin WhatsApp Support (Help Desk)",
                                color = WhatsAppGreen,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "Disputes, deposit verification & help",
                                color = TextMutedSlate,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Open",
                        tint = WhatsAppGreen
                    )
                }
            }
        }

        // Admin Panel Shortcut (Only visible to verified Admin)
        if (isAdmin) {
            Spacer(modifier = Modifier.height(20.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onNavigateToAdmin() },
                colors = CardDefaults.cardColors(containerColor = CardSlateBg),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(AmberGold)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = AmberGold
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Admin Control Panel",
                                color = AmberGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Tournaments, Room Codes & Wallets",
                                color = TextMutedSlate,
                                fontSize = 11.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Open",
                        tint = AmberGold
                    )
                }
            }
        }

        // Sign Out Button
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = {
                Firebase.auth.signOut()
                scope.launch {
                    try {
                        credentialManager.clearCredentialState(ClearCredentialStateRequest())
                    } catch (e: Exception) {
                        // Safe exception absorption during credential cleanup
                    }
                    onSignOut()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = RedSignOut,
                contentColor = Color.White
            )
        ) {
            Text(
                text = "🚪 Sign Out",
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }

    // Dialog: Set DLS Team Name & Gamer ID
    if (showDlsDialog) {
        AlertDialog(
            onDismissRequest = { if (!isSaving) showDlsDialog = false },
            containerColor = CardSlateBg,
            title = {
                Text(
                    text = "Set DLS Team & Gamer ID",
                    color = AmberGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Enter your Dream League Soccer in-game team name and gamer ID for tournament matching:",
                        color = TextMutedSlate,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = dlsTeamInput,
                        onValueChange = { dlsTeamInput = it },
                        label = { Text("DLS Team Name / In-Game ID") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberGold,
                            unfocusedBorderColor = DividerSlate,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (dlsTeamInput.isBlank()) {
                            Toast.makeText(context, "Team name cannot be empty", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        isSaving = true
                        scope.launch {
                            val uid = liveProfile?.id?.takeIf { it.isNotBlank() } ?: currentUser?.id ?: repository.getCurrentUserId() ?: ""
                            val currentName = liveProfile?.name?.takeIf { it.isNotBlank() } ?: currentUser?.name ?: "Player"
                            val currentPhone = liveProfile?.phoneNumber ?: currentUser?.phoneNumber ?: ""
                            val res = repository.updateUserProfile(
                                uid = uid,
                                name = currentName,
                                phone = currentPhone,
                                dlsTeamName = dlsTeamInput.trim(),
                                photoUrl = liveProfile?.photoUrl ?: currentUser?.photoUrl
                            )
                            if (res.isSuccess) {
                                Toast.makeText(context, "DLS Gamer Profile updated!", Toast.LENGTH_SHORT).show()
                                showDlsDialog = false
                            } else {
                                Toast.makeText(context, "Failed to update profile", Toast.LENGTH_SHORT).show()
                            }
                            isSaving = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberGold,
                        contentColor = Color.Black
                    )
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black)
                    } else {
                        Text("Save Profile", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showDlsDialog = false }) {
                    Text("Cancel", color = TextMutedSlate)
                }
            }
        )
    }

    // Dialog: Password Reset Link
    if (showPasswordDialog) {
        val userEmail = currentUser?.email ?: Firebase.auth.currentUser?.email ?: ""
        AlertDialog(
            onDismissRequest = { showPasswordDialog = false },
            containerColor = CardSlateBg,
            title = {
                Text(
                    text = "Password Reset Link",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "A secure password reset link will be dispatched to your registered email address:\n\n$userEmail",
                        color = TextLightSlate,
                        fontSize = 13.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (userEmail.isNotBlank()) {
                            Firebase.auth.sendPasswordResetEmail(userEmail)
                                .addOnSuccessListener {
                                    Toast.makeText(
                                        context,
                                        "Reset email sent! Please check your inbox.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    showPasswordDialog = false
                                }
                                .addOnFailureListener {
                                    Toast.makeText(
                                        context,
                                        "Failed to send reset email: ${it.localizedMessage}",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberGold,
                        contentColor = Color.Black
                    )
                ) {
                    Text("Send Reset Link", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPasswordDialog = false }) {
                    Text("Cancel", color = TextMutedSlate)
                }
            }
        )
    }

    // Dialog: Update Phone Number
    if (showPhoneDialog) {
        AlertDialog(
            onDismissRequest = { if (!isSaving) showPhoneDialog = false },
            containerColor = CardSlateBg,
            title = {
                Text(
                    text = "Update Bkash/Nagad Number",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Provide your active mobile number for deposit verification and withdrawals:",
                        color = TextMutedSlate,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("Mobile Number (01XXXXXXXXX)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberGold,
                            unfocusedBorderColor = DividerSlate,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (phoneInput.isBlank()) {
                            Toast.makeText(context, "Phone number cannot be empty", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        isSaving = true
                        scope.launch {
                            val uid = liveProfile?.id?.takeIf { it.isNotBlank() } ?: currentUser?.id ?: repository.getCurrentUserId() ?: ""
                            val currentName = liveProfile?.name?.takeIf { it.isNotBlank() } ?: currentUser?.name ?: "Player"
                            val currentTeam = liveProfile?.dlsTeamName ?: currentUser?.dlsTeamName ?: ""
                            val res = repository.updateUserProfile(
                                uid = uid,
                                name = currentName,
                                phone = phoneInput.trim(),
                                dlsTeamName = currentTeam,
                                photoUrl = liveProfile?.photoUrl ?: currentUser?.photoUrl
                            )
                            if (res.isSuccess) {
                                Toast.makeText(context, "Phone number updated successfully!", Toast.LENGTH_SHORT).show()
                                showPhoneDialog = false
                            } else {
                                Toast.makeText(context, "Failed to update phone number", Toast.LENGTH_SHORT).show()
                            }
                            isSaving = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = AmberGold,
                        contentColor = Color.Black
                    )
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black)
                    } else {
                        Text("Update Number", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showPhoneDialog = false }) {
                    Text("Cancel", color = TextMutedSlate)
                }
            }
        )
    }

    // Dialog: Edit Profile & Photo
    if (showEditProfileDialog) {
        val avatarOptions = listOf(
            "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=300" to "Striker",
            "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?w=300" to "Champion",
            "https://images.unsplash.com/photo-1518091043644-c1d4457512c6?w=300" to "Goalkeeper",
            "" to "Default"
        )

        AlertDialog(
            onDismissRequest = { if (!isSaving) showEditProfileDialog = false },
            containerColor = CardSlateBg,
            title = {
                Text(
                    text = "Edit Profile & Picture",
                    color = AmberGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text("Choose Player Avatar:", color = TextMutedSlate, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        avatarOptions.forEach { (url, label) ->
                            val isSelected = editPhotoUrlInput == url
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .clip(CircleShape)
                                    .background(if (isSelected) AmberGold else CardSlateBg)
                                    .border(2.dp, if (isSelected) AmberGold else DividerSlate, CircleShape)
                                    .clickable { editPhotoUrlInput = url }
                                    .padding(2.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (url.isNotBlank()) {
                                    AsyncImage(
                                        model = url,
                                        contentDescription = label,
                                        modifier = Modifier.fillMaxSize().clip(CircleShape),
                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                    )
                                } else {
                                    Image(
                                        painter = painterResource(id = R.drawable.ic_player_avatar),
                                        contentDescription = label,
                                        modifier = Modifier.size(36.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = editNameInput,
                        onValueChange = { editNameInput = it },
                        label = { Text("Player Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberGold,
                            unfocusedBorderColor = DividerSlate,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it },
                        label = { Text("Bkash/Nagad Mobile Number") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberGold,
                            unfocusedBorderColor = DividerSlate,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = dlsTeamInput,
                        onValueChange = { dlsTeamInput = it },
                        label = { Text("DLS Team & Gamer ID") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberGold,
                            unfocusedBorderColor = DividerSlate,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = ffNameInput,
                        onValueChange = { ffNameInput = it },
                        label = { Text("Free Fire In-Game Name (IGN)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberGold,
                            unfocusedBorderColor = DividerSlate,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = ffUidInput,
                        onValueChange = { ffUidInput = it },
                        label = { Text("Free Fire UID (FF UID)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberGold,
                            unfocusedBorderColor = DividerSlate,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = editPhotoUrlInput,
                        onValueChange = { editPhotoUrlInput = it },
                        label = { Text("Custom Photo URL (Optional)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AmberGold,
                            unfocusedBorderColor = DividerSlate,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val uid = liveProfile?.id?.takeIf { it.isNotBlank() } ?: currentUser?.id ?: repository.getCurrentUserId() ?: ""
                        if (uid.isBlank()) return@Button
                        isSaving = true
                        scope.launch {
                            val res = repository.updateUserProfile(
                                uid = uid,
                                name = editNameInput.trim().ifBlank { "Player" },
                                phone = phoneInput.trim(),
                                dlsTeamName = dlsTeamInput.trim(),
                                photoUrl = editPhotoUrlInput.trim(),
                                ffInGameName = ffNameInput.trim(),
                                ffUid = ffUidInput.trim()
                            )
                            if (res.isSuccess) {
                                Toast.makeText(context, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
                                showEditProfileDialog = false
                            } else {
                                Toast.makeText(context, "Update failed", Toast.LENGTH_SHORT).show()
                            }
                            isSaving = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = Color.Black)
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black)
                    } else {
                        Text("Save Profile", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditProfileDialog = false }) {
                    Text("Cancel", color = TextMutedSlate)
                }
            }
        )
    }

    // Dialog: Telegram Support Link
    if (showTelegramDialog) {
        val tgChannel = paymentSettings.telegramLink.ifBlank { "https://t.me/AYCITY_DLS" }
        AlertDialog(
            onDismissRequest = { showTelegramDialog = false },
            containerColor = CardSlateBg,
            title = {
                Text(
                    text = "✈️ Official Telegram Channel",
                    color = TelegramBlue,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Join our official Telegram community for daily tournament match schedules and updates:",
                        color = TextLightSlate,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = tgChannel,
                        color = AmberGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        launchTelegramSupport(context, tgChannel)
                        showTelegramDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = TelegramBlue,
                        contentColor = Color.Black
                    )
                ) {
                    Text("Open Telegram", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showTelegramDialog = false }) {
                    Text("Close", color = TextMutedSlate)
                }
            }
        )
    }

    // Dialog: WhatsApp Admin Support Link
    if (showWhatsAppDialog) {
        val waNumber = paymentSettings.whatsappNumber.ifBlank { "+8801700000000" }
        val cleanNumber = waNumber.replace("+", "").replace(" ", "").replace("-", "")
        AlertDialog(
            onDismissRequest = { showWhatsAppDialog = false },
            containerColor = CardSlateBg,
            title = {
                Text(
                    text = "🟢 WhatsApp Admin Support",
                    color = WhatsAppGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "Need help with a deposit, withdrawal, or match result? Chat directly with AY CITY Admin via WhatsApp:",
                        color = TextLightSlate,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "WhatsApp: $waNumber",
                        color = AmberGold,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        try {
                            val url = "https://wa.me/$cleanNumber"
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            clipboardManager.setText(AnnotatedString(waNumber))
                            Toast.makeText(context, "WhatsApp number copied to clipboard!", Toast.LENGTH_SHORT).show()
                        }
                        showWhatsAppDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = WhatsAppGreen,
                        contentColor = Color.White
                    )
                ) {
                    Text("Open WhatsApp", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showWhatsAppDialog = false }) {
                    Text("Close", color = TextMutedSlate)
                }
            }
        )
    }
}

fun launchTelegramSupport(context: android.content.Context, rawLink: String) {
    val trimmed = rawLink.trim()
    val url = when {
        trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
        trimmed.startsWith("tg://") -> trimmed
        trimmed.startsWith("@") -> "https://t.me/${trimmed.removePrefix("@")}"
        trimmed.startsWith("t.me/") -> "https://$trimmed"
        trimmed.isBlank() -> "https://t.me/AYCITY_DLS"
        else -> "https://t.me/$trimmed"
    }
    try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    } catch (e: Exception) {
        try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(browserIntent)
        } catch (e2: Exception) {
            android.widget.Toast.makeText(context, "Telegram: $url", android.widget.Toast.LENGTH_LONG).show()
        }
    }
}
