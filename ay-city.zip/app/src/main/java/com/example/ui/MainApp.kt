package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SportsSoccer
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.ADMIN_UID
import com.example.data.repository.AppRepository
import com.example.ui.admin.AdminPanelScreen
import com.example.ui.auth.AuthScreen
import com.example.ui.leaderboard.LeaderboardScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.theme.AyCyan
import com.example.ui.theme.AyDarkBackground
import com.example.ui.theme.AyEmerald
import com.example.ui.theme.AyGold
import com.example.ui.theme.AyPitchBlack
import com.example.ui.theme.AySurfaceBorder
import com.example.ui.theme.AySurfaceCard
import com.example.ui.theme.AySurfaceCardElevated
import com.example.ui.theme.AyTextMuted
import com.example.ui.theme.AyTextPrimary
import com.example.ui.theme.AyTextSecondary
import com.example.ui.tournament.TournamentScreen
import com.example.ui.wallet.WalletScreen
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(repository: AppRepository) {
    var firebaseUser by remember { mutableStateOf(Firebase.auth.currentUser) }
    val scope = rememberCoroutineScope()

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { auth ->
            firebaseUser = auth.currentUser
        }
        Firebase.auth.addAuthStateListener(listener)
        onDispose {
            Firebase.auth.removeAuthStateListener(listener)
        }
    }

    if (firebaseUser == null) {
        AuthScreen(
            repository = repository,
            onAuthSuccess = {
                firebaseUser = Firebase.auth.currentUser
            }
        )
    } else {
        val uid = firebaseUser!!.uid
        val currentUserProfile by repository.observeUserProfile(uid).collectAsState(initial = null)

        val context = LocalContext.current
        var selectedNavTab by remember { mutableIntStateOf(0) } // 0: Tournaments, 1: Wallet, 2: Leaderboard, 3: Profile
        var isShowingAdminPanel by remember { mutableStateOf(false) }

        var showLogoMenu by remember { mutableStateOf(false) }
        var showRulesDialog by remember { mutableStateOf(false) }
        var showNoticeDialog by remember { mutableStateOf(false) }
        var showAboutDialog by remember { mutableStateOf(false) }

        val paymentSettings by repository.observePaymentSettings().collectAsState(initial = com.example.data.model.PaymentSettings())
        val appNotice by repository.observeAppNotice().collectAsState(initial = com.example.data.model.AppNotice())

        val isAdmin = uid == ADMIN_UID || currentUserProfile?.role == "admin"

        if (isShowingAdminPanel) {
            BackHandler {
                isShowingAdminPanel = false
            }
            AdminPanelScreen(
                repository = repository,
                onBack = { isShowingAdminPanel = false }
            )
        } else {
            BackHandler(enabled = selectedNavTab != 0) {
                selectedNavTab = 0
            }

            Scaffold(
                containerColor = AyDarkBackground,
                topBar = {
                    TopAppBar(
                        title = {
                            Box {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { showLogoMenu = true }
                                        .padding(horizontal = 4.dp, vertical = 4.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.ay_city_logo),
                                        contentDescription = "Logo",
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .border(1.dp, AyGold, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "AY CITY",
                                            fontWeight = FontWeight.Black,
                                            color = AyGold,
                                            fontSize = 17.sp,
                                            letterSpacing = 1.sp
                                        )
                                        Text(
                                            text = "DLS TOURNAMENT ▾",
                                            fontWeight = FontWeight.Bold,
                                            color = AyTextSecondary,
                                            fontSize = 9.sp,
                                            letterSpacing = 0.5.sp
                                        )
                                    }
                                }

                                DropdownMenu(
                                    expanded = showLogoMenu,
                                    onDismissRequest = { showLogoMenu = false },
                                    modifier = Modifier.background(AySurfaceCardElevated)
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("📢 অফিশিয়াল নোটিশ", color = AyGold, fontWeight = FontWeight.SemiBold) },
                                        leadingIcon = { Icon(Icons.Default.Campaign, contentDescription = null, tint = AyGold) },
                                        onClick = {
                                            showLogoMenu = false
                                            showNoticeDialog = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("📜 টুর্নামেন্ট ও খেলার নিয়মাবলী", color = AyTextPrimary) },
                                        leadingIcon = { Icon(Icons.Default.MenuBook, contentDescription = null, tint = AyCyan) },
                                        onClick = {
                                            showLogoMenu = false
                                            showRulesDialog = true
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("💬 হোয়াটসঅ্যাপ সাপোর্ট", color = AyEmerald) },
                                        leadingIcon = { Icon(Icons.Default.SupportAgent, contentDescription = null, tint = AyEmerald) },
                                        onClick = {
                                            showLogoMenu = false
                                            val cleanNumber = paymentSettings.whatsappNumber.replace("+", "").replace(" ", "").replace("-", "")
                                            try {
                                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$cleanNumber"))
                                                context.startActivity(intent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "WhatsApp: ${paymentSettings.whatsappNumber}", Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("✈️ টেলিগ্রাম সাপোর্ট চ্যানেল", color = AyCyan) },
                                        leadingIcon = { Icon(Icons.Default.SupportAgent, contentDescription = null, tint = AyCyan) },
                                        onClick = {
                                            showLogoMenu = false
                                            com.example.ui.profile.launchTelegramSupport(context, paymentSettings.telegramLink)
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("🔄 পেজ রিফ্রেশ করুন", color = AyTextSecondary) },
                                        leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null, tint = AyTextSecondary) },
                                        onClick = {
                                            showLogoMenu = false
                                            Toast.makeText(context, "ডাটা রিফ্রেশ করা হয়েছে ✓", Toast.LENGTH_SHORT).show()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("ℹ️ AY CITY সম্পর্কে", color = AyTextSecondary) },
                                        leadingIcon = { Icon(Icons.Default.Info, contentDescription = null, tint = AyTextMuted) },
                                        onClick = {
                                            showLogoMenu = false
                                            showAboutDialog = true
                                        }
                                    )
                                }
                            }
                        },
                        actions = {
                            // Admin Quick Button (If Admin)
                            if (isAdmin) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(AyGold)
                                        .clickable { isShowingAdminPanel = true }
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.AdminPanelSettings,
                                            contentDescription = "Admin",
                                            tint = AyPitchBlack,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "এডমিন",
                                            color = AyPitchBlack,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                            }

                            // Wallet Balance Pill
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(AySurfaceCardElevated)
                                    .border(1.dp, AyGold.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                                    .clickable { selectedNavTab = 1 }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.AccountBalanceWallet,
                                        contentDescription = "Wallet",
                                        tint = AyGold,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "৳ ${"%.2f".format(currentUserProfile?.walletBalance ?: 5.0)}",
                                        color = AyGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(containerColor = AySurfaceCard)
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = AySurfaceCard,
                        contentColor = AyGold
                    ) {
                        val navItems = listOf(
                            Triple("টুর্নামেন্ট", Icons.Default.SportsSoccer, 0),
                            Triple("ওয়ালেট", Icons.Default.AccountBalanceWallet, 1),
                            Triple("লিডারবোর্ড", Icons.Default.EmojiEvents, 2),
                            Triple("প্রোফাইল", Icons.Default.Person, 3)
                        )

                        navItems.forEach { (title, icon, index) ->
                            val isSelected = selectedNavTab == index
                            NavigationBarItem(
                                selected = isSelected,
                                onClick = { selectedNavTab = index },
                                icon = {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = title,
                                        tint = if (isSelected) AyGold else AyTextMuted
                                    )
                                },
                                label = {
                                    Text(
                                        text = title,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) AyGold else AyTextMuted,
                                        fontSize = 11.sp
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = AyGold,
                                    selectedTextColor = AyGold,
                                    indicatorColor = AyGold.copy(alpha = 0.15f),
                                    unselectedIconColor = AyTextMuted,
                                    unselectedTextColor = AyTextMuted
                                )
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    AnimatedContent(
                        targetState = selectedNavTab,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "NavTransition"
                    ) { targetTab ->
                        when (targetTab) {
                            0 -> TournamentScreen(
                                repository = repository,
                                currentUser = currentUserProfile,
                                onNavigateToWallet = { selectedNavTab = 1 }
                            )
                            1 -> WalletScreen(
                                repository = repository,
                                currentUser = currentUserProfile
                            )
                            2 -> LeaderboardScreen(
                                repository = repository
                            )
                            3 -> ProfileScreen(
                                repository = repository,
                                currentUser = currentUserProfile,
                                onNavigateToAdmin = { isShowingAdminPanel = true },
                                onSignOut = { firebaseUser = null }
                            )
                        }
                    }
                }
            }

            // Rules Dialog
            if (showRulesDialog) {
                AlertDialog(
                    onDismissRequest = { showRulesDialog = false },
                    containerColor = AySurfaceCardElevated,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = AyGold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("DLS টুর্নামেন্ট ও খেলার নিয়মাবলী", color = AyGold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    },
                    text = {
                        Column {
                            Text("১. ম্যাচ শুরুর অন্তত ১০ মিনিট আগে রুমে জয়েন করতে হবে।", color = AyTextPrimary, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("২. কোনো ধরনের হ্যাক বা আনফেয়ার উপায় অবলম্বন করলে একাউন্ট ব্যান হবে।", color = AyTextPrimary, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("৩. ম্যাচ শেষে উইনিং স্ক্রিনশট ও স্কোর টেলিগ্রাম/হোয়াটসঅ্যাপে এডমিনকে সাবমিট করুন।", color = AyTextPrimary, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("৪. জয়েন করার পর এন্ট্রি ফি রিফান্ডেবল নয় যদি ম্যাচ শুরু হয়ে যায়।", color = AyTextPrimary, fontSize = 13.sp)
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { showRulesDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
                        ) {
                            Text("বুঝেছি", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            // Notice Board Dialog
            if (showNoticeDialog) {
                AlertDialog(
                    onDismissRequest = { showNoticeDialog = false },
                    containerColor = AySurfaceCardElevated,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Campaign, contentDescription = null, tint = AyGold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(appNotice.title.ifBlank { "অফিশিয়াল নোটিশ বোর্ড" }, color = AyGold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    },
                    text = {
                        Column {
                            Text(
                                text = appNotice.message.ifBlank { "বর্তমানে কোনো বিশেষ নোটিশ নেই।" },
                                color = AyTextPrimary,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { showNoticeDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
                        ) {
                            Text("ঠিক আছে", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }

            // About Dialog
            if (showAboutDialog) {
                AlertDialog(
                    onDismissRequest = { showAboutDialog = false },
                    containerColor = AySurfaceCardElevated,
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Image(
                                painter = painterResource(id = R.drawable.ay_city_logo),
                                contentDescription = null,
                                modifier = Modifier.size(24.dp).clip(CircleShape)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("AY CITY সম্পর্কে", color = AyGold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                    },
                    text = {
                        Column {
                            Text("AY CITY - Dream League Soccer (DLS) টুর্নামেন্ট ও ই-স্পোর্টস প্ল্যাটফর্ম।", color = AyTextPrimary, fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("ভার্সন: ১.২.০ (অফিশিয়াল রিলিজ)", color = AyTextSecondary, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("লাইভ ম্যাচ, ইনস্ট্যান্ট ট্রানজেকশন ও ২৪/৭ ডেডিকেটেড সাপোর্ট।", color = AyTextMuted, fontSize = 12.sp)
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { showAboutDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = AyGold, contentColor = AyPitchBlack)
                        ) {
                            Text("বন্ধ করুন", fontWeight = FontWeight.Bold)
                        }
                    }
                )
            }
        }
    }
}
