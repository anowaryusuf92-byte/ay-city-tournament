package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Branding - AY CITY Gold & Emerald Stadium
val AyGold = Color(0xFFFFD700)
val AyGoldVariant = Color(0xFFEAB308)
val AyGoldDark = Color(0xFFCA8A04)

val AyEmerald = Color(0xFF10B981)
val AyEmeraldDark = Color(0xFF059669)

val AyCyan = Color(0xFF38BDF8)
val AyRed = Color(0xFFEF4444)

// Dark Theme Surfaces
val AyPitchBlack = Color(0xFF070B14)
val AyDarkBackground = Color(0xFF0B132B)
val AySurfaceCard = Color(0xFF111E3D)
val AySurfaceCardElevated = Color(0xFF18284F)
val AySurfaceBorder = Color(0xFF2A3E6B)

val AyTextPrimary = Color(0xFFF8FAFC)
val AyTextSecondary = Color(0xFF94A3B8)
val AyTextMuted = Color(0xFF64748B)

val AyBkashPink = Color(0xFFE2136E)
val AyNagadOrange = Color(0xFFF7931E)
