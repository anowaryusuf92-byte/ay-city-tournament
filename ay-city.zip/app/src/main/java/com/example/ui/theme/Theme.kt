package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AyGold,
    onPrimary = AyPitchBlack,
    primaryContainer = AyGoldDark,
    onPrimaryContainer = AyGold,
    secondary = AyEmerald,
    onSecondary = Color.White,
    secondaryContainer = AyEmeraldDark,
    onSecondaryContainer = Color.White,
    tertiary = AyCyan,
    onTertiary = AyPitchBlack,
    background = AyDarkBackground,
    onBackground = AyTextPrimary,
    surface = AySurfaceCard,
    onSurface = AyTextPrimary,
    surfaceVariant = AySurfaceCardElevated,
    onSurfaceVariant = AyTextSecondary,
    outline = AySurfaceBorder,
    error = AyRed,
    onError = Color.White
)

@Composable
fun AyCityTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
