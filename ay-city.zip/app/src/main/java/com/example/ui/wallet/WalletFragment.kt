package com.example.ui.wallet

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.R
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.firestore

class WalletFragment : Fragment() {

    private var balanceListener: ListenerRegistration? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_wallet, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvWalletBalance: TextView = view.findViewById(R.id.tvWalletBalance)
        val userId = Firebase.auth.currentUser?.uid

        if (userId != null) {
            // Real-time snapshot listener on exact same field (walletBalance) in "Players" collection
            balanceListener = Firebase.firestore.collection("Players").document(userId)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        tvWalletBalance.text = "৳ 5.00"
                        return@addSnapshotListener
                    }

                    if (snapshot != null && snapshot.exists()) {
                        // Extract walletBalance field matching the top app bar
                        val balance = snapshot.getDouble("walletBalance") ?: 5.0
                        tvWalletBalance.text = "৳ ${"%.2f".format(balance)}"
                    } else {
                        // Default to 5.00 BDT welcome bonus for new accounts
                        tvWalletBalance.text = "৳ 5.00"
                    }
                }
        } else {
            tvWalletBalance.text = "৳ 5.00"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        balanceListener?.remove()
        balanceListener = null
    }
}
