package com.example

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import com.example.data.model.ADMIN_UID
import com.example.data.model.AdminAlert
import com.example.data.model.AppNotice
import com.example.data.repository.AppRepository
import com.example.ui.MainApp
import com.example.ui.theme.AyCityTheme
import com.example.ui.theme.AyDarkBackground
import com.example.util.NotificationHelper
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Initialize Android System Push Notification Channels
        NotificationHelper.createNotificationChannels(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
            }
        }

        // Setup Real-time Notification Dispatcher
        setupSystemPushListeners()

        setContent {
            val repository = remember { AppRepository(this.applicationContext) }

            AyCityTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = AyDarkBackground
                ) {
                    MainApp(repository = repository)
                }
            }
        }
    }

    private fun setupSystemPushListeners() {
        val db = Firebase.firestore
        val auth = Firebase.auth

        lifecycleScope.launch {
            var lastNoticeTimestamp: Long = System.currentTimeMillis()

            // 1. User Broadcast System Notifications (from settings/app_notice)
            db.collection("settings").document("app_notice")
                .addSnapshotListener { snap, _ ->
                    if (snap != null && snap.exists()) {
                        val notice = snap.toObject(AppNotice::class.java)
                        val noticeTime = notice?.createdAt?.toDate()?.time ?: System.currentTimeMillis()
                        if (notice != null && notice.isActive && notice.message.isNotBlank() && noticeTime > lastNoticeTimestamp) {
                            lastNoticeTimestamp = noticeTime
                            NotificationHelper.showBroadcastNoticeNotification(
                                context = applicationContext,
                                title = "📢 " + notice.title.ifBlank { "নতুন অফিশিয়াল নোটিশ" },
                                message = notice.message
                            )
                        }
                    }
                }

            // 2. Admin System Push Notifications (from admin_alerts collection)
            var lastAlertTimestamp: Long = System.currentTimeMillis()
            db.collection("admin_alerts")
                .addSnapshotListener { snaps, _ ->
                    val currentUid = auth.currentUser?.uid
                    if (currentUid == ADMIN_UID && snaps != null) {
                        for (change in snaps.documentChanges) {
                            if (change.type == com.google.firebase.firestore.DocumentChange.Type.ADDED) {
                                val alert = change.document.toObject(AdminAlert::class.java)
                                val alertTime = alert.createdAt?.toDate()?.time ?: System.currentTimeMillis()
                                if (!alert.isRead && alertTime >= (lastAlertTimestamp - 5000)) {
                                    lastAlertTimestamp = alertTime
                                    NotificationHelper.showAdminAlertNotification(
                                        context = applicationContext,
                                        title = "⚡ " + alert.title.ifBlank { "নতুন ট্রানজেকশন অ্যালার্ট" },
                                        message = alert.message
                                    )
                                }
                            }
                        }
                    }
                }
        }
    }
}
