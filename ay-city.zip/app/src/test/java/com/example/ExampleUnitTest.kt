package com.example

import com.example.data.model.PaymentSettings
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun paymentSettings_defaultLimits_areValid() {
    val settings = PaymentSettings()
    assertEquals(20.0, settings.minDeposit, 0.001)
    assertEquals(50.0, settings.minWithdraw, 0.001)
    assertTrue(settings.minDeposit > 0.0)
    assertTrue(settings.minWithdraw >= settings.minDeposit)
  }

  @Test
  fun playerUid_formatAndDeterminism_areValid() {
    val sampleUid1 = "user_abc_123"
    val playerUid1 = com.example.data.repository.AppRepository.generatePlayerUid(sampleUid1)
    val playerUid1Again = com.example.data.repository.AppRepository.generatePlayerUid(sampleUid1)

    // Must match format AY-XXXXX (e.g., AY-10024)
    val regex = Regex("^AY-\\d{5}$")
    assertTrue("Generated UID $playerUid1 must match format AY-XXXXX", regex.matches(playerUid1))
    assertEquals("Generated UID must be deterministic for same user UID", playerUid1, playerUid1Again)

    val blankGenerated = com.example.data.repository.AppRepository.generatePlayerUid("")
    assertTrue("Generated UID from blank must also match format AY-XXXXX", regex.matches(blankGenerated))
  }
}

